# -*- coding: utf-8 -*-
"""
@author: bmary
"""
from __future__ import print_function
import numpy as np
import cathy_tools as CT

def create_nansf():
    
    pass

def create_atmbc(HSPATM=0,IETO=0):
    
    pass







# class RHIZO(object):
#     '''Main RHIZO object.'''
    # def __init__(self,dirName,prjName='my_cathy_prj'):
        
        
  
        
    

# rhizo.create_infitration(drippersPos=[],RWU=False)
#     # closestnode
#     # simu.create_parm()
#     # simu.create_soil()
#     # simu.create_ic()
#     # simu.create_atmbc()
#     # simu.create_nansfdirbc()

# rhizo.create_DA(drippersPos=[],RWU=False)
#     # closestnode
#     # simu.create_parm()
    
    