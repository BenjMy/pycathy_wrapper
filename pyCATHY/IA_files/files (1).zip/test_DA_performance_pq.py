"""Regression test for the performance (N)RMSE bookkeeping (README step 3.5).

Needs only numpy, pandas, pyarrow: pyCATHY is NOT imported, the methods are
extracted from cathy_DA.py with `ast` and bound to a stub object.

Run:  python test_performance_pq.py
"""

import ast
import os
import tempfile
import textwrap

import numpy as np
import pandas as pd

HELPERS = {  # module-level, self-free functions
    "_compute_diff_matrix",
    "_compute_rmse",
    "_get_rmse_for_sensor",
    "_append_to_performance_df",
    "_save_performance_to_parquet",
    "_load_performance_from_parquet",
}
METHOD = "_performance_assessment_pq"  # method of DA, bound to a stub below


def _find_cathy_DA():
    """cathy_DA.py next to this script, or in the repository layout (pyCATHY/DA)."""
    here = os.path.dirname(os.path.abspath(__file__))
    for candidate in (
        os.path.join(here, "cathy_DA.py"),
        os.path.join(here, "..", "DA", "cathy_DA.py"),
    ):
        if os.path.exists(candidate):
            return candidate
    raise FileNotFoundError("cathy_DA.py not found next to this test or in ../DA")


def make_stub():
    path = _find_cathy_DA()
    src = open(path).read()
    tree = ast.parse(src)
    ns = {"np": np, "pd": pd, "os": os}
    segments = [
        ast.get_source_segment(src, n)
        for n in tree.body
        if isinstance(n, ast.FunctionDef) and n.name in HELPERS
    ]
    assert len(segments) == len(
        HELPERS
    ), "performance helpers not found at module level"
    exec("\n".join(segments), ns)
    method = next(
        ast.get_source_segment(src, n)
        for n in ast.walk(tree)
        if isinstance(n, ast.FunctionDef) and n.name == METHOD
    )
    exec(textwrap.dedent(method), ns)

    class Stub:
        layout = None  # {key: data array}: observations with several data under one key

        def _get_data2assimilate(self, lst, time_ass=None, match=False):
            if self.layout is not None:
                if (
                    match
                ):  # the data of one key; the "sensor names" list is the key itself
                    return np.asarray(self.layout[lst[0]], float), [lst[0]]
                return np.hstack(list(self.layout.values())), list(self.layout)
            if match:  # observations and sensor names of one observation type
                return np.array([1.0, 2.0]), ["p1", "p2"]
            return np.array([1.0, 2.0]), ["tensio"]  # observation type names

    Stub._performance_assessment_pq = ns[METHOD]
    stub = Stub()
    stub.workdir, stub.project_name = tempfile.mkdtemp(), "proj"
    os.makedirs(os.path.join(stub.workdir, "proj"))
    return stub


def pred(abs_error, n_ens=3):
    """(2 obs, n_ens) prediction whose absolute error is `abs_error` everywhere."""
    return np.array([1.0, 2.0])[:, None] + abs_error * np.ones((2, n_ens))


def test_performance_pq():
    st, data = make_stub(), np.array([1.0, 2.0])
    run = lambda err, t, ol: st._performance_assessment_pq(
        ["tensio"], data, pred(err), t, openLoop=ol
    )

    run(0.5, 0, False)  # DA cycle 0
    run(1.5, 1, False)  # DA cycle 1
    run(10.0, 0, True)  # open loop cycle 0 (must not pollute DA)
    run(20.0, 1, True)  # open loop cycle 1
    run(0.5, 2, False)  # DA cycle 2

    df = pd.read_parquet(
        os.path.join(st.workdir, "proj", "proj_df_performance.parquet")
    )
    assert (
        len(df) == 5
    ), f"one row per (cycle, sensor, mode), got {len(df)}"  # no duplication

    da = df[~df["OL"]].set_index("time")
    ol = df[df["OL"]].set_index("time")
    # RMSE averages over the 3 ensemble members (not over the 2 observations)
    assert np.isclose(da.loc[0, "RMSEtensio"], 0.5)
    # cumulative NRMSE = running mean over cycles of the same mode
    assert np.isclose(da.loc[1, "NMRMSEtensio"], (0.5 + 1.5) / 2)
    assert np.isclose(da.loc[2, "NMRMSEtensio"], (0.5 + 1.5 + 0.5) / 3)
    assert np.isclose(da.loc[2, "NMRMSE_avg"], (0.5 + 1.5 + 0.5) / 3)
    assert np.isclose(ol.loc[1, "NMRMSEtensio"], (10 + 20) / 2)
    print("OK")


def test_performance_multi_datum():
    """One key can hold several data (e.g. one ERT survey of 3 measurements): the sensor
    takes as many rows of the prediction as it has data, and the next sensor follows."""
    st = make_stub()
    st.layout = {"ERT": [1.0, 2.0, 3.0], "tensio0": [10.0]}
    data = np.array([1.0, 2.0, 3.0, 10.0])
    prediction = data[:, None] + np.array([[0.5], [0.5], [0.5], [2.0]]) * np.ones(
        (4, 3)
    )
    st._performance_assessment_pq(["all"], data, prediction, 0, openLoop=False)
    df = pd.read_parquet(
        os.path.join(st.workdir, "proj", "proj_df_performance.parquet")
    )
    by_sensor = df.set_index("ObsType")
    assert np.isclose(by_sensor.loc["ERT", "RMSEERT"], 0.5)  # rows 0-2
    assert np.isclose(by_sensor.loc["tensio0", "RMSEtensio0"], 2.0)  # row 3, not row 1
    assert np.isclose(df["RMSE_avg"].iloc[0], (3 * 0.5 + 2.0) / 4)  # over all the data
    print("OK multi-datum")


if __name__ == "__main__":
    test_performance_pq()
    test_performance_multi_datum()
