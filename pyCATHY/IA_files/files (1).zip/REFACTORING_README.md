# Refactoring Guide: `cathy_DA.py`

A practical, step-by-step plan for refactoring the `DA` class (pyCATHY data assimilation) into something smaller, testable, and safer to change.

> **Constraint: everything stays in a single file (`cathy_DA.py`).** Structure comes from clearly delimited sections, module-level pure functions, small dataclasses, and short methods, not from new modules. The only code that lives elsewhere is what already does (`enkf`, `pf`, `mapper`, `localisation`, `cathy_inputs`, ...).


> **Scope rule (relaxed by the maintainer): other pyCATHY files may now be modified when it simplifies the work** (first used for `pyCATHY/DA/observations.py`). Originally: **only `cathy_DA.py` may be modified** (one explicit exception was granted by the maintainer: the CATHY source pin in `pyCATHY/cathy_tools.py`, see the log entry "Pin of the CATHY sources"). Do not edit any other pyCATHY file (`enkf.py`, `pf.py`, `observations.py`, `perturbate.py`, `performance.py`, `cathy_tools.py`, ...): fetch them read-only from GitHub for reference. The only other file an AI request may update is the progress log (section 11) of this README. Helper/test scripts (`test_*.py`, `baseline_tool.py`, `dev_check_*.py`) are separate, additive files and must never be a reason to change pyCATHY code: if a pyCATHY function behaves oddly, work around it inside `cathy_DA.py` (or in a throw-away script) and note it in the "Findings" list instead.
>
> **Source of truth for dependencies: GitHub, not PyPI.** The `pyCATHY` package on PyPI is outdated (e.g. 0.1.1 has no `enkf_analysis_localized_with_inflation`, and `pf.py` differs). If you need any source file that `cathy_DA.py` imports (`enkf`, `pf`, `mapper`, `localisation`, `cathy_tools`, `cathy_inputs`, ...), fetch it from the repository:
> <https://github.com/BenjMy/pycathy_wrapper/tree/main/pyCATHY>
> e.g. `curl -sfL -O https://raw.githubusercontent.com/BenjMy/pycathy_wrapper/main/pyCATHY/DA/enkf.py`
> **Do not use `pip install pycathy` / PyPI sources to check signatures or behaviour.**

---

## 0. Hand-over summary (current state)

**Done.** The refactoring plan (sections 3-5) and the suggestions of section 12 are finished; the long log is in section 11. Results are unchanged: every step was checked against real CATHY runs.

| | At the start | Now |
|---|---|---|
| `cathy_DA.py` | ~3,300 lines, 1 function + 1 class | 3,575 lines (docstrings and types included): 21 module functions/classes + `DA` with 69 short methods |
| `run_DA_sequential` | 467 lines | 93 (about half is docstring); loop body in `_run_window` |
| `apply_ensemble_updates` | 347 | 64 |
| `_DA_analysis` | 319 | 127 |
| `map_states2Observations` | 294 | 67 |
| `run_analysis` | 187 | 58 |
| `_update_soil_params_from_perturbations` | 153 | 82 |
| `_check_after_analysis` | 137 | 33 |
| `print()` calls / bare `except:` | ~97 / 7 | 0 / 0 (`logging`, typed exceptions) |
| `os.chdir` | 5, unscoped | `_working_directory` context manager + one explicit call |

**Verification (final file).**
- 13 real CATHY runs, each identical to a reference captured with the code before the corresponding step: cases 1 (states), 2 (Ks), 3 (localisation nodes), 5 (tensiometers), 6 (ET), 7 (porosity), 9 (window without observation), 10 (serial), 11 (n_VG), 12 (Feddes), 13 (WTPOSITION), 15 (log observations), 16 (localisation nodes, one sensor). Compared: `df_DA`, `df_performance`, `dict_parm_pert`, `ET_DA_xr`. Run them with `run_all_cases.sh` (`CAPTURE=1` once to create the references).
- Unit tests (no CATHY needed): `test_DA_run_analysis.py` (filters, config, checks, dispatchers, state, windows...) and `test_DA_performance_pq.py`; ruff and black clean; CI workflow `.github/workflows/da-quality.yml` (not yet run on GitHub).
- **Not covered by any real run:** EM and ERT observations, the `atmbc` branch, `layers` / `root_map` soil controls, `veg_map` / `zones` localisation, Archie-only parameters. They are split and unit-tested with substituted parts only.

**Where the delivered files go (repository `pycathy_wrapper`).**
`cathy_DA.py` -> `pyCATHY/DA/`; `observations.py`, `perturbate.py` -> `pyCATHY/DA/`; `cathy_tools.py` -> `pyCATHY/` (also in `pycathy_pin_cathy_src.patch`, with the two others, against `pycathy_wrapper` `55bb7cf`); `test_DA_*.py` -> `pyCATHY/tests/`; `pyproject.toml` (tool settings appended) -> repository root; `da-quality.yml` -> `.github/workflows/`; `baseline_case_run.py`, `run_all_cases.sh`, `baseline_tool.py` stay outside the package (development tools).

**Decisions waiting for you** (details in "Findings not yet fixed" and "Checks to do" of section 11):
1. `atmbc` parameters inside a DA run reject 100 % of the members (present in the code received; mechanism written down).
2. `atmbc_pert_rules` gives NaN when a time step exceeds the decorrelation length.
3. Substring tests (`name in "ks"`) in the parameter dispatch instead of equality.
4. `run_DA_smooth` is an unfinished stub: finish or remove.
5. A real EM and a real ERT case are needed before touching those mappers (same "one survey per assimilation time" rule to apply to EM).

*Decided and applied since:* with localisation the performance is now assessed on all the observations (it used the first zone's data only), and ERT is mapped once per cycle (two ERT keys raise).

**Practical notes.** One run needs ~2-3 GB: run the cases one at a time (two at once were killed, exit 137) and use `NO_COV_PLOT=1` below ~4 GB. Each run writes ~115 MB: delete the work directories. The CATHY sources are now pinned to a commit (`pyCATHY/cathy_tools.py`, `CATHY_SRC_COMMIT`): upgrade it deliberately and re-run the cases.

---

## 1. Where things stand (at the start; current numbers in section 0)

`cathy_DA.py` is ~3,300 lines: one module-level function (`run_analysis`) and one class (`DA(CATHY)`) with ~37 methods. Several methods are very long:

| Method | Approx. lines | Role |
|---|---|---|
| `run_DA_sequential` | 467 | main DA loop |
| `apply_ensemble_updates` | 347 | writes states/params into ensemble input files |
| `_DA_analysis` | 319 | prepares data/states/params, calls filter |
| `map_states2Observations` | 294 | H operator for all observation types |
| `run_analysis` | 187 | dispatcher to `enkf` / `pf` |
| `_update_soil_params_from_perturbations` | 153 | soil parameter updates |
| `_check_after_analysis` | 137 | post-analysis checks |

Code-smell counts: ~97 `print()` calls plus ~38 `console.print()` calls mixed together, 7 bare `except:` blocks, 5 `os.chdir()` calls, 11 `hasattr()` checks used as state flags.

**Goal:** make each unit do one thing, remove hidden state, and make the filter/mapping logic testable without running CATHY.

---

## 2. Ground rules before touching anything

1. **Freeze current behaviour first (characterisation tests).** Run one small, fast DA case (e.g. 3-5 ensemble members, 2 observation times, tensiometer only) and save the outputs: `df_performance` parquet, `df_DA`, and the analysis arrays. These are your regression baseline.
2. **One refactor per commit.** Never mix "move code" with "change behaviour".
3. **Keep the public API stable.** Users call `run_DA_sequential`, `run_DA_smooth`, `map_states2Observations`, `set_Archie_parm`, `apply_ensemble_updates`. Keep these names (thin wrappers if needed) until the end.
4. **Order of work:** fix bugs → delete dead code → extract pure functions → extract classes → clean state. Don't reverse this.

---

## 3. Step 0: Fix definite bugs first (small, high value)

These are visible in the current code. Fix them in their own commits *before* restructuring, and note that fixing them may change results.

### 3.1 `run_analysis`
- **Unreachable branch:** `if DA_type == "pf"` appears twice. The second one (calling `pf.pf_analysis`, prints "not yet implemented") can never execute. Delete it.
- **`localisationMatrix` is popped twice:** `L = kwargs.pop('localisationMatrix', None)` runs at the top, then the `enkf_analysis_localized` branch does `kwargs.pop('localisationMatrix')` with no default → `KeyError`. Use the `L` already read.
- **Argument order inconsistency:** every call passes `(data, data_cov, param, ensembleX[id_state], prediction, ...)` *except* `enkf_analysis_localized_with_inflation`, which passes `ensembleX[id_state]` **before** `param`. Check the signature in `enkf.py`. Either it is a real bug or the signature differs. Use keyword arguments to make this unambiguous.
- **Hard-coded values override inputs:** `Sakov=True` is hard-coded in `enkf_analysis_localized`. **Decision: make it user-configurable** (see below). The PF branch also ignores the `jitter_params`/`inflate_*` values parsed above it (it hard-codes `jitter_std_param=0.01`, `jitter_std_state=0.05`, `resample_threshold=0.5`); expose those through `AnalysisConfig` as well.
  - Pass `Sakov=cfg.sakov` (and read it from the `Sakov` kwarg in the legacy shim) in `enkf_analysis_localized`.
  - **Keep the default `True`** so existing runs give identical results. Only the localized variants read `cfg.sakov`; the variants whose names already encode the choice (`enkf_Evensen2009`, `enkf_Evensen2009_Sakov`, `enkf_dual_analysis`, `enkf_dual_analysis_Sakov`) keep their fixed behaviour.
  - Note that `enkf_analysis_localized_with_inflation` already honours `Sakov=Sakov`, so after this change both localized variants behave consistently.
  - Emit the "Sakov is True" warning at most once, not on every analysis step.
- **Warnings fire for every call:** `warnings.warn("Sakov is True")` etc. run on every analysis step. Move defaults into a config object (Section 5.1) and warn at most once.

### 3.2 `run_DA_sequential`
- `check_ensemble` is a nested function defined inside the loop on every iteration. Move it out (and make it a proper `logging.warning`).
- `remov_convert = False` / `hard_remove = False` are dead flags guarding file deletion. Turn them into explicit keyword arguments (`cleanup_vtk=False`) or delete the block.
- The `if localisation` branch contains the message *"ONLY TAKE THE first part of the data? Need to refactor performance assessment"* followed by `data = data[0]`. This is a known unresolved issue, so write a test that documents the current behaviour and open a ticket instead of leaving it in a print statement.
- `hasattr(self, 'localisationMatrix') > 0` (in `_DA_analysis`) compares a bool to 0. It works by accident. Replace with `getattr(self, "localisationMatrix", None) is not None`.

### 3.3 Bare `except:` (7 places: lines ~1317, 1492, 2383, 2720, 2733, 2925, 3090)
Replace each with the specific exception (`FileNotFoundError`, `KeyError`, `OSError`, ...). Bare excepts swallow `KeyboardInterrupt` and hide real failures. For example, `_create_subfolders_ensemble` prints *"processor exe not found"* on **any** error.

### 3.4 `apply_ensemble_updates`
- `kwargs["cycle_nb"]` is accessed unguarded in the state-update block even though the earlier code treats `cycle_nb` as optional (`if "cycle_nb" in kwargs`). Make `cycle_nb` an explicit parameter with default `0`.
- In the `else` branch there is code after a `raise ValueError(...)` that can never run. Delete it.
- `analysis` is only defined `if "analysis" in kwargs`, so a later reference can raise `NameError`. Make it an explicit parameter defaulting to `None`.

### 3.5 `_performance_assessement_pq`
- `hasattr(self, 'df_performance') is False` → creates an empty frame; otherwise it **reloads from parquet**, which fails or silently resets if the file does not yet exist. Always go through `_load_performance_from_parquet` (which already handles the missing file case).
- `_compute_diff_matrix` uses a double Python loop. Replace with `np.abs(data[:, None] - prediction)` (check shapes first; `data` may be 1-D or `(n, 1)`).
- Column names like `"RMSE" + name_sensor` produce a different schema per sensor and a very sparse DataFrame. Use a long format: `time, obs_type, rmse, nrmse, rmse_avg, nrmse_avg, open_loop`.
- `NMRMSE` is a typo of `NRMSE` and is also stored in the parquet schema. Rename it with a one-time migration for old files.

---

## 4. Step 1: Cleanup that needs no design decisions

- Remove unused imports (`multiprocessing`, `concurrent.futures`, `time`, `re`, `copy`, `subprocess`, `xr` if unused, `track`, `mt`, `plt_CT`, `out_CT`, `dictObs_2pd`, `subprocess_run_multi` may or may not be used; verify with `ruff --select F401`).
- Delete commented-out code blocks (`# from functools import partial`, old `invalid = ...` checks, `# t_obs = 3`, etc.). Git remembers them.
- Remove the global `warnings.filterwarnings("ignore", category=DeprecationWarning)`. A library should not silence warnings process-wide. Fix or locally suppress the specific ones.
- `REMOVE_CPU = 5` is a module constant with no explanation. Move it next to its use and document it, or make it a parameter.
- Replace mutable default arguments (`list_update_parm=["St. var."]`, `ens_valid=[]`, `obs_valid=[]`, `porosity=[]`, `rFluid_Archie=[1.0]`, ...) with `None` and set the value inside the function.
- Fix the module docstring (`consit`, mismatched section numbering) and make method names consistent (`assessement` → `assessment`).
- Run `black` + `ruff` once, in a commit that contains *only* formatting.

---

## 5. Step 2: Structural refactor

### 5.1 Replace `**kwargs` plumbing with config objects

Options currently travel as `**kwargs` through `run_DA_sequential → prepare_DA → run_processor`, and are read in four different ways (`kwargs.get`, `kwargs.pop`, `"x" in kwargs`, `kwargs[...]`). Introduce dataclasses:

```python
from dataclasses import dataclass, field
from typing import Optional
import numpy as np

@dataclass
class AnalysisConfig:
    da_type: str = "enkf_Evensen2009_Sakov"
    default_state: str = "psi"            # "psi" or "sw"
    sakov: bool = True
    inflation_states: float = 1.0
    inflation_params: float = 1.0
    jitter_params: float = 0.0
    localisation_matrix: Optional[np.ndarray] = None

@dataclass
class DAConfig:
    parallel: bool = True
    threshold_rejected: int = 10
    localisation: Optional[list[str]] = None   # e.g. ["veg_map", "zones", "nodes"]
    use_log_transformed_obs: bool = False
    backup_fort777: bool = False
    cleanup_vtk: bool = False
    verbose: bool = False
    analysis: AnalysisConfig = field(default_factory=AnalysisConfig)
```

`run_DA_sequential(..., config: DAConfig | None = None, **legacy_kwargs)` can build a `DAConfig` from legacy kwargs (and emit a `DeprecationWarning`) so existing scripts keep working.

### 5.2 Turn `run_analysis` into a registry (not an if-chain)

Almost every branch is the same call with a different function and one flag. Replace the 187-line if-chain with a lookup:

```python
# module level in cathy_DA.py (section: ANALYSIS)

def _call_enkf(fn, **extra):
    def run(data, cov, param, state, pred, cfg):
        return fn(data, cov, param, state, pred, **extra)
    return run

ANALYSES = {
    "enkf_Evensen2009":         _call_enkf(enkf.enkf_analysis),
    "enkf_Evensen2009_Sakov":   _call_enkf(enkf.enkf_analysis, Sakov=True),
    "enkf_dual_analysis":       _call_enkf(enkf.enkf_dual_analysis, Sakov=False),
    "enkf_dual_analysis_Sakov": _call_enkf(enkf.enkf_dual_analysis, Sakov=True),
    # localized / inflation / pf variants: small dedicated adapters that read
    # cfg.sakov, cfg.inflation_*, cfg.jitter_params, cfg.localisation_matrix
}

def run_analysis(da_type, data, cov, param, ensembleX, prediction, cfg):
    state = ensembleX[1 if cfg.default_state == "sw" else 0]
    try:
        return ANALYSES[da_type](data, cov, param, state, prediction, cfg)
    except KeyError:
        raise ValueError(f"Unknown DA_type {da_type!r}. Available: {sorted(ANALYSES)}")
```

Also fix the silent fall-through: an unknown `DA_type` currently returns `None` and fails later with a confusing error.

**Return types are inconsistent** (PF returns a dict with `n_eff`/`resampled`; the old PF stub returns a tuple; EnKF variants return other shapes). Define one `AnalysisResult` dataclass (`analysis_state`, `analysis_param`, `diagnostics: dict`) and adapt each filter to it.

### 5.3 Organise the single file into sections

Keep one file, but give it a fixed, predictable order so it can be navigated (and so that any section could be moved out later without surgery). Use banner comments (`# %% ====` also works as cell markers in Spyder/VS Code, which you already use with `#%%`):

```
cathy_DA.py
├── 0. Module docstring + imports + constants
├── 1. CONFIG            dataclasses: AnalysisConfig, DAConfig, AnalysisResult
├── 2. ANALYSIS          registry + run_analysis (pure functions, no `self`)
├── 3. PERFORMANCE       rmse / nrmse / parquet helpers (pure functions, no `self`)
├── 4. MASKS & CHECKS    build_obs_node_mask, validate_prediction, update_key, ...
├── 5. OBSERVATION MAPPERS   small mapper classes/functions per obs type (5.5)
├── 6. class DA(CATHY)
│       ├── public API              run_DA_sequential, run_DA_smooth, map_states2Observations,
│       │                           apply_ensemble_updates, set_Archie_parm
│       ├── setup                   _DA_init, prepare_DA, _create_subfolders_ensemble
│       ├── loop steps              _predict_observations, _analyse, _analyse_with_localisation, ...
│       ├── ensemble I/O            _read_state_ensemble, _update_input_ensemble, _update_*
│       ├── diagnostics             _check_before_analysis, _check_after_analysis, ...
│       └── results & backups       _DA_df, _DA_ET_xr, backup_*
└── (optional) __all__ = ["DA", "run_analysis", ...]
```

Rules that make a single big file stay manageable:

1. **Sections 1-5 are module-level and `self`-free.** Anything that doesn't need the object state becomes a plain function taking explicit arguments. This is where the unit tests go, and it is where most of the line count shrinks.
2. **Inside `DA`, group methods in the order above** and mark each group with a comment banner. Public methods first, private helpers after.
3. **Prefix private helpers consistently** (`_`) and keep the public names listed in "Ground rules" unchanged.
4. **No new circular concerns:** module-level functions must not import or call `DA`. `DA` calls them, never the reverse.
5. **Use `__all__`** to state the public surface explicitly.
6. **Soft size budget:** the aim is that the file ends up *shorter* than today (dead code, duplicated branches, `print`s, and the long if-chains go away), even though new dataclasses and helpers are added. Re-check `wc -l` after each PR.

If the file later becomes too large, sections 1-5 are the natural first candidates to split out, since they have no dependency on `self`.

### 5.4 Break up `run_DA_sequential` (467 lines)

Target a loop body that reads like the docstring:

```python
for t_atmbc in self.all_atmbc_times[:-1]:
    self._run_ensemble_hydrological_model(parallel, callexe)
    rejected = self._validate_ensemble_before_analysis(threshold_rejected)

    if t_atmbc in self.ENS_times:
        prediction = self._predict_observations(list_assimilated_obs, parallel)
        self._validate_prediction(prediction)                     # raises on NaN / <=0
        result = self._analyse(prediction, DA_type, ...)          # localised or not
        self._record_performance(result, prediction)
        self._update_parameter_dict(result)
    else:
        result = self._no_analysis_result()

    self._save_step_outputs(result, rejected)
    self._write_next_inputs(result)
    self._log_step_progress(t_atmbc)
```

Concrete extractions, in this order (easiest first):

1. **Prediction validation block** (NaN / negative check + error message) → `_validate_prediction(prediction)`. Note the ET special case (`< 0` allowed to be zero vs. `<= 0` otherwise).
2. **Console `rule(...)` progress messages** (~25 lines) → `_log_step_progress(...)`.
3. **Results/backups** (`_DA_df`, `_DA_ET_xr`, `backup_fort777`, `backup_results_DA`, `backup_simu`) → `_save_step_outputs(...)`.
4. **VTK cleanup** → `_cleanup_vtk_files(remove_converted, remove_all)`.
5. **Localisation loop** (~130 lines, the largest nested block) → `_analyse_with_localisation(...)`, returning the same `(ensemble_psi, ensemble_sw, data, analysis, analysis_param)` tuple as the non-localised path. This unifies the two branches so the loop doesn't care which one ran.
6. **Observation-node validity logic** inside the localisation loop (`obs_surface_nodes_bool`, EM tiling with `np.hstack`) → a pure function `build_obs_node_mask(mask_surface_nodes, node_value, n_nodes, n_obs_blocks)` with unit tests. The block that prints "NOT IMPLEMENTED YET" should become a real `logging.warning`, and the comparison `len(mesh_nodes_observed) <= len(obs_surface_nodes_valid)` should be checked. The message says the opposite condition from what the code tests.

> **`run_DA_smooth` (experimental, kept for future tests):** it is not deprecated, but it is not the main path either, so do **not** spend refactoring effort on it. Rules:
> - Mark it experimental in the docstring (and optionally emit a `UserWarning` on call).
> - Keep its signature and behaviour unchanged during this refactor.
> - It already shares setup with `run_DA_sequential` (`prepare_DA`, init, update). It benefits automatically from the extracted helpers (`DAConfig`, `_analyse`, `_validate_prediction`, ...). Switch it to them only where this is a trivial substitution, never as a prerequisite for a PR.
> - Add one small smoke test (tiny ensemble) so that breakage from the refactor of the shared helpers is caught.
> - Revisit once it is used for real: either promote it (give it the same treatment as the sequential loop) or remove it.

### 5.5 Split `map_states2Observations` (294 lines) by observation type

It currently branches on substrings of the key (`"tensio" in obs_key`, `"swc"`, `"stemflow"`, `"scale"`, `"discharge"`, `"EM"`, `"ERT"`, `ET`), with ERT handled in a separate second loop and a parallel path. Convert to one small mapper per type behind a common interface:

```python
class ObservationMapper(Protocol):
    def matches(self, obs_key: str) -> bool: ...
    def map(self, ens_dir, state, obs_nodes, ctx) -> np.ndarray: ...

MAPPERS = [TensiometerMapper(), SWCMapper(), DischargeMapper(), ScaleMapper(),
           StemflowMapper(), EMMapper(), ERTMapper(), ETMapper()]
```

Substring matching (`"EM" in obs_key`) is fragile (`"EM"` would also match any key containing those letters), so match on the structured `data_type` field where possible. The ERT mapper (Archie + porosity per ensemble, the `unique_count` porosity diagnostic, parallel branch) is the most complex. Move it to its own class in the `OBSERVATION MAPPERS` section (the module docstring already mentions a `mappingERT` class; the existing `pyCATHY.DA.mapper` module can keep the low-level numerics) and keep the parallel/serial decision in one place.

### 5.6 Split `apply_ensemble_updates` (347 lines)

It handles states, Feddes, VG, soil Ks/porosity, Archie, initial conditions, and atmbc in one method. Make one function per parameter family:

```
_update_state_ic(...)       # "St. var." → update_ic
_update_feddes(...)
_update_vg(...)
_update_soil_spp(...)       # Ks, porosity (already partly in _update_soil_params_from_perturbations)
_update_archie(...)         # already exists as update_archie_parameter
_update_atmbc(...)
```

`apply_ensemble_updates` then loops over `list_parm2update` and dispatches. This also removes the many accumulator lists initialised at the top (`Feddes_withPertParam`, `ks_het_ens`, `POROS_het_ens`, `VG_p_het_ens`, `Archie_parms_mat_ens`, ...).

### 5.7 Remove `os.chdir` (5 places)

`os.chdir` changes global process state: it breaks parallel use, tests, and any code that assumes a working directory. Replace with explicit paths (you already build `forward_path_i` in several places), and pass `cwd=` to `subprocess.run` when launching the executable. If a CATHY routine truly needs the cwd, wrap it in a context manager:

```python
from contextlib import contextmanager

@contextmanager
def working_directory(path):
    prev = os.getcwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(prev)
```

### 5.8 Make state explicit

`DA` stores most things as attributes created lazily in different methods (`self.localisationBool`, `self.isET`, `self.ens_valid`, `self.df_performance`, `self.Archie_parms_mat_ens`, ...), and the code guards with `hasattr`. This makes call order matter silently.

- Initialise every attribute in one place (`__init__`/`_DA_init`) with a default.
- Group related fields in small dataclasses, e.g. `EnsembleState(ens_valid, NENS, rejected)` and `DACycle(count_DA_cycle, count_atmbc_cycle)`.
- `self.isET` is set inside `map_states2Observations` but read in `run_DA_sequential`. Return it or compute it from `list_assimilated_obs` instead.
- Consider the `update_key` logic (`"ini_perturbation"` vs `"update_nb" + str(n)`), which is duplicated in `_DA_analysis`, `apply_ensemble_updates`, and `_DA_init`. Put it in one helper: `update_key(cycle_nb)`.

### 5.9 Logging

Replace the ~97 `print()` and mixed `console.print()` calls with the `logging` module (`logger = logging.getLogger(__name__)`). Keep `rich` for the progress/rule display only through a single `RichHandler` or a small `ui.py` helper. This lets users control verbosity (you already have `self.verbose`) and lets tests run quietly. Remove the placeholder messages such as `print(['Im done with _invalid_ensemble']*10)`, `print("!shortcut here ensemble are not validated!")` (printed twice), and stray `print(list_parm2update)`.

---

## 6. Step 3: Performance (only after tests pass)

- `_append_to_performance_df` calls `pd.concat` once per sensor per cycle and then the whole file is read, concatenated and rewritten every cycle. Collect rows in a list and write once per cycle (or append using a partitioned Parquet dataset).
- `_compute_diff_matrix`: vectorise (see 3.5).
- `map_states2Observations` reads the soil file and maps porosity to the mesh **for every ensemble member at every DA cycle**. Cache what doesn't change between cycles (mesh markers, observation node indices) and only re-read what the analysis modifies.
- Profile before optimising: `python -m cProfile -o da.prof run_case.py`, then inspect with `snakeviz`. The hydrological model runs will probably dominate, so check that the Python-side work is actually significant first.

---

## 7. Testing plan

| Layer | What to test | Needs CATHY? |
|---|---|---|
| Pure functions | `run_analysis` registry (unknown type raises), RMSE/NRMSE, `build_obs_node_mask`, `update_key`, prediction validation, inflation/jitter | No |
| Filters | Small synthetic problem with known solution (linear H, Gaussian prior): analysis mean/spread move toward obs; localisation with identity vs. zero matrix | No |
| Mappers | Each mapper on a toy state vector and node list | No |
| Config | Legacy `**kwargs` → `DAConfig` conversion, including defaults and warnings | No |
| Integration | One tiny end-to-end DA run compared to the baseline saved in Step "Ground rules" | Yes (mark `@pytest.mark.slow`) |

Compare against the baseline with tolerances (`np.testing.assert_allclose(rtol=1e-6)`); ensemble perturbations must use a fixed seed.

---

## 8. Suggested order of PRs

1. Add baseline integration test + CI (`pytest`, `ruff`, `black --check`).
2. Fix bugs in Section 3 (one commit each).
3. Cleanup in Section 4 (imports, dead code, mutable defaults, formatting).
4. Move the performance helpers and `run_analysis` into the `PERFORMANCE` and `ANALYSIS` sections as `self`-free functions (pure, easiest, high test value).
5. Introduce `DAConfig` with legacy-kwargs shim.
6. Replace `print` with `logging`; remove `os.chdir`.
7. Break up `run_DA_sequential` (5.4), starting with the small extractions.
8. Split `map_states2Observations` (5.5) and `apply_ensemble_updates` (5.6).
9. Reorder the file into the sections of 5.3 (pure move, no logic changes, so keep it in its own commit).
10. Make state explicit (5.8); performance work (Section 6).

After each PR: all tests green, baseline integration test unchanged (unless the PR is a deliberate bug fix, in which case say so in the commit message).

---

## 9. Definition of done

- No method over ~60 lines; no function with more than ~7 parameters (use config objects).
- No bare `except:`, no `os.chdir` outside the context manager (one explicit call left in `run_DA_sequential`), no mutable default arguments.
- No `print()` in library code (**done** in `cathy_DA.py`; `console.print` is the kept UI layer).
- Every `DA_type` and observation type has at least one unit test that does not require running CATHY.
- Everything is still in `cathy_DA.py`, ordered by the sections in 5.3, and `from pyCATHY.DA.cathy_DA import DA, run_analysis` still works.
- Existing example scripts run unchanged (possibly with a `DeprecationWarning`).

---

## 10. Decisions and open questions

**Decided**

1. **`Sakov` is user-configurable** for `enkf_analysis_localized` (default stays `True` to preserve current results). See 3.1.
2. **`run_DA_smooth` is kept as an experimental feature for future tests.** It is not deprecated and not refactored beyond what the shared helpers give it for free. See 5.4.

3. **`enkf_analysis_localized` branch removed** from `run_analysis`: the function does not exist in pyCATHY GitHub `main` (only `enkf_analysis_localized_with_inflation`, which is kept and receives `Sakov`). Use `DA_type="enkf_analysis_localized_with_inflation"`.
4. **`psi`/`sw` fill value is now really `1e99`** (`np.full`), and the "missing values" check only looks at `ens_valid` members (rejected members legitimately stay at the fill value).
5. **`df_performance` keeps the wide layout and the `NMRMSE` column names**: `pyCATHY.plotters.cathy_plots.DA_RMS` reads `RMSE<sensor>`, `NMRMSE_avg` and `OL`, so renaming or a long format must be done together with that plotter. Documented in `_append_to_performance_df`.
6. **Performance maths corrected** (see 3.5 in the log): mean over ensemble members, history restricted to the same mode (`OL`) and to previous cycles, `NMRMSE_avg` accumulates over cycles.

**Still open (resolve before the related refactor)**

1. ~~Argument order of `enkf_analysis_localized_with_inflation`~~: resolved, intentional (see section 11).
2. What is the intended behaviour with localisation when several zones have different observation sets (`data = data[0]` currently drops the rest for performance assessment)?
3. ~~`df_performance` layout~~: decided, keep the wide layout (Decided item 5). A long format stays possible later if `DA_RMS` is migrated at the same time.

---

## 11. Progress log (for further AI requests)

> Sections 1-10 are the original plan and keep the original names (e.g. `_performance_assessement_pq`, now `_performance_assessment_pq`). Update this section after every step. Mark steps `[x]` only when the code is changed **and** `python -m py_compile cathy_DA.py` passes **and** `ruff check cathy_DA.py --select F401,F821,F811,B006` is clean (`py_compile` alone does NOT catch undefined names: a step-3.2 edit once put `cleanup_vtk` in the wrong method and only ruff F821 revealed it) **and** `python test_performance_pq.py` prints `OK` **and** `PYTHONPATH=/tmp/pcgh:. python test_run_analysis.py` prints `OK` (see the setup entry below). Nothing has been run against CATHY yet (no baseline test exists), so every change below is unverified at runtime.

### Done

- [x] **3.1 `run_analysis` fixes** (behaviour-preserving except where noted)
  - Deleted the unreachable second `if DA_type == "pf"` branch (the one calling `pf.pf_analysis`).
  - Removed the second `kwargs.pop('localisationMatrix')` (would raise `KeyError`); the `L` read at the top is reused.
  - `enkf_analysis_localized` now uses `Sakov=Sakov` (read from the `Sakov` kwarg, **default still `True`**, so results are unchanged by default).
  - PF settings are now overridable via kwargs `pf_resample_threshold` (0.5), `pf_jitter_std_param` (0.01), `pf_jitter_std_state` (0.05); defaults equal the old hard-coded values. These will become `AnalysisConfig` fields in 5.1.
  - Warnings ("Sakov is True", "L not provided", inflation/jitter defaults) go through `_warn_once(key, msg)` and fire once per process instead of every analysis step.
  - Unknown `DA_type` now raises `ValueError` instead of silently returning `None`. **Behaviour change** (previously failed later with a confusing error).
- [x] **3.2 `run_DA_sequential` / `_DA_analysis` cleanup**
  - `hasattr(self,'localisationMatrix')>0` replaced by `getattr(self, 'localisationMatrix', None) is not None`.
  - Nested `check_ensemble` (redefined every cycle, ignored `ensemble_sw_valid`) replaced by module-level `_check_positive_pressure_heads(ensemble_psi)`.
  - Dead flags `remov_convert` / `hard_remove` replaced by the kwarg `cleanup_vtk` (`False` default, `'converted'` or `'all'`). The `glob` no longer runs when cleanup is off. Default behaviour unchanged (nothing deleted).
  - Fixed a `SyntaxWarning` (`re.split("(\\d+)", key)` is now a raw string).
- [x] **3.3 Bare `except:` removed** (0 left in the file)
  - New module-level `_READ_ERRORS = (OSError, ValueError, KeyError, IndexError)` for missing/empty/malformed CATHY output files; used for mbeconv, psi, sw and ET reads. The exception type and message are now printed where the old code printed a generic message.
  - Plot of DA matrices: `except Exception` (diagnostics only, must never abort a run, but `KeyboardInterrupt` now propagates).
  - `np.array(Hx_ens)` conversion: only `ValueError` (ragged list) is swallowed.
  - Processor-file copy into `cathy_origin`: `except OSError` with the real error in the message (the old message "processor exe not found" was misleading when `copytree` failed for another reason).
  - **Risk:** if a read function raises something outside `_READ_ERRORS` (e.g. `AttributeError` from the `rio` accessor in `_DA_ET_xr`), the run now stops instead of silently continuing. Widen the tuple if that happens.
- [x] **3.4 `apply_ensemble_updates`**
  - `cycle_nb` (default 0) and `analysis` (default `None`) are read once via `kwargs.get`; all `kwargs["cycle_nb"]` lookups replaced (removes the `KeyError`/`UnboundLocalError` when they were omitted).
  - Raises a clear `ValueError` if `cycle_nb > 0`, `"St. var."` is updated and `analysis` is `None`.
  - Deleted the unreachable code after the `raise ValueError("no state variable update ...")`.
  - Signature is still `**kwargs`; promoting them to named parameters is left for the API pass (5.x) to avoid touching the 2 call sites now.

- [x] **3.5 `_performance_assessment_pq`** (renamed from `assessement` in step 4)
  - **Bug fixed (changes outputs):** the method reloaded the parquet into `self.df_performance`, appended the new rows, then `_save_performance_to_parquet` appended that whole frame to the file again. Rows were duplicated at every cycle (cycles 0..3 with one sensor gave 15 rows instead of 4) and the cumulative `prev_rmse` sum used for NRMSE was inflated by the duplicates. Now: load existing rows via `_load_performance_from_parquet` (handles a missing file), build only the new rows in `df_new`, append those to the file. Existing parquet files written by the old code may already contain duplicated rows; they are not repaired automatically.
  - The file path is built once with `os.path.join(workdir, project_name, ...)`.
  - `self.df_performance` is still reset to an empty frame at the end (nothing else in the file reads it).
  - `_compute_diff_matrix` was **already vectorised** in the uploaded file (broadcast `np.abs(data[:, None] - prediction)`); nothing to do.
  - **Maths corrected (changes outputs; decided on readability/intent):**
    - `_compute_rmse` is now `mean(nanmean(diff, axis=1))`: average over ensemble members, then over observations. Before it divided by `len(prediction)` (the number of observations) instead of the ensemble size, wrong whenever `n_obs != n_ens`. Its `num_predictions` argument was removed.
    - Cumulative sums (`NMRMSE<sensor>`, `NMRMSE_avg`) only use previous cycles (`time < t_obs`) of the **same mode** (`OL == openLoop`), so open-loop rows no longer pollute DA rows.
    - `NMRMSE_avg` is the running mean over cycles of `RMSE_avg` (before: `n_sensors * current / (t+1)`, no history).
    - If an old parquet holds rows with the same `time` from a previous run of the same project, they still count as history (the schema has no run id).
  - **Kept on purpose:** wide layout and `NMRMSE` names (Decided item 5).
  - Regression test `test_performance_pq.py` (extracts the performance methods by AST; needs only numpy/pandas/pyarrow, not pyCATHY): checks no duplication, ensemble averaging, cumulative NRMSE and open-loop/DA separation. Run `python test_performance_pq.py`.

- [x] **4 Cleanup (partial)**
  - Removed unused imports (`concurrent.futures`, `time`, `meshtools as mt`; **`dictObs_2pd` was removed here by mistake and restored later as a documented re-export, see "CI, `__all__` and the `dictObs_2pd` fix"**); the other imports listed in Section 4 are in fact used (ruff F401 clean).
  - Removed the process-wide `warnings.filterwarnings("ignore", DeprecationWarning)` and a dead `# from functools import partial`.
  - `REMOVE_CPU` -> `RESERVED_CPUS` (documented) and `Pool(processes=max(1, cpu_count() - RESERVED_CPUS))` (it failed with 5 cores or fewer).
  - All 15 mutable default arguments replaced by `None` + in-body defaults (`_DA_analysis`, `_check_before_analysis`, `_update_input_ensemble`, `_DA_df`, `set_Archie_parm`); ruff B006 clean.
  - Deleted 59 lines of commented-out code (ruff ERA001); 2 prose comments kept.
  - Module docstring typo fixed; `_performance_assessement_pq` renamed `_performance_assessment_pq` (private, 3 occurrences).
  - **Bug introduced and fixed in this step:** the step-3.2 `cleanup_vtk` kwarg had landed in `run_DA_smooth` instead of `run_DA_sequential` (NameError on every sequential run). It is now in `run_DA_sequential`.
  - Unused variables (ruff F841) removed. `read_outputs` is a pure file read (checked in GitHub `cathy_tools.py`), so dropping the unused `df_psi` read in `apply_ensemble_updates` and the unused `df_dtcoupling` read in `map_states2Observations` only removes wasted I/O (and a `FileNotFoundError` if the file was missing). Also removed `match_ic_withLayers`, `data_range`/`prediction_range`, and the unused `NENS = []` in `_DA_df`.
  - **`black` applied in its own commit** (`cathy_DA.py` and `test_performance_pq.py`). Verified that the AST is identical before/after, ignoring whitespace inside docstrings, so no behaviour change. Line count 3218 -> 3286. Keep using `black` from now on; do not hand-format.

- [x] **Real-code verification setup + `run_analysis` tests**
  - `cathy_DA` now **imports and runs against the GitHub pyCATHY** in the AI sandbox (clone with `git clone --depth 1 https://github.com/BenjMy/pycathy_wrapper /tmp/pcgh`, then `PYTHONPATH=/tmp/pcgh:.`). Extra packages needed: `pip install shapely xarray rich rioxarray pyvista ipywidgets natsort geopandas gitpython pyarrow` (+ `ruff black` for tooling). This is still **not** a CATHY run (no executable, no model output), so the characterisation baseline of Section 2 (Ground rules) point 1 remains to be built on a real install.
  - New `test_run_analysis.py` (skips itself if `cathy_DA` cannot be imported): all EnKF variants + localized-with-inflation + PF run on a synthetic problem, unknown `DA_type` and the removed `enkf_analysis_localized` raise `ValueError`.
  - **Bug found by that test and fixed in `_DA_analysis`:** for state-only updates `param_valid` was `[]`; `enkf_analysis_inflation` fails on an empty list (`ValueError` on concatenation) but works on an empty `(0, n_members)` array, which gives numerically identical results for the plain EnKF variants. `param_valid` is now `np.zeros((0, len(ens_valid)))` in that case.

- [x] **5.2 `run_analysis` registry + `AnalysisResult`**
  - The 150-line if-chain is replaced by an `ANALYSES` dict of small adapters (`_enkf(...)` factory, `_enkf_localized_with_inflation`, `_particle_filter`) in a new ANALYSIS section above the `DA` class; `run_analysis` keeps exactly the same signature and kwargs, so no caller changed. Adding a filter = one line in `ANALYSES`.
  - **Verified numerically identical** to the pre-refactor function: 10 cases (every DA type, with and without parameters, `psi` and `sw`) with the same random seed, `np.allclose` on every returned array (old and new raise the same errors where they fail). The one-off script is kept as `dev_check_run_analysis_equivalence.py`; it needs the previous version of the file as `/tmp/cathy_DA_old.py` (`git show <commit before 5.2>:cathy_DA.py`), so it is documentation of the check, not part of the regular test run.
  - Small intended differences: (1) warnings ("Sakov is True", "L not provided", inflation/jitter defaults) are now emitted only by the DA types that use those options (before: for every DA type); (2) the unknown-`DA_type` error now lists the available types; (3) `list_update_parm` is still accepted but unused.
  - **`AnalysisResult` dataclass** (`analysis` (n_state, n_members), `analysis_param` (n_members, n_param), `diagnostics` dict of the 9 EnKF matrices or `None`, `extra` for PF outputs). `run_analysis` now returns it for every DA type; adapters convert through `_from_enkf` / `_particle_filter`. `_DA_analysis` lost its `hasattr/len(...) > 2/DA_type != "pf"` branching and the 11-element unpacking: it uses `result_analysis.analysis`, `.analysis_param` and plots only if `.diagnostics is not None`. **API change:** callers of `run_analysis` outside this file that indexed the old list/dict must be updated (none found in the GitHub sources).
  - **Real bug fixed on the way (changes behaviour for `enkf_analysis_localized_with_inflation` with parameters):** that filter returns the parameter ensemble as `(n_param, n_members)` whereas every other filter returns `(n_members, n_param)` (PF is transposed by the old code). `_DA_analysis` / `_mark_invalid_ensemble` assume `(n_members, n_param)` (`analysis_param.shape[1]`, `len(analysis_param[0]) > 0`, `np.hstack(analysis_param)`), so parameters were mis-shaped (and the state-only case wrongly looked non-empty) with the localized filter. The adapter now transposes it. Verified: all other DA types are numerically identical to the pre-5.2 version (`dev_check_run_analysis_equivalence.py`, localized compared after transposition).
  - `test_run_analysis.py` now checks the result type and the orientations (`analysis`, `analysis_param`) for every filter, with and without parameters.

- [x] **5.1 `AnalysisConfig` (analysis part only; `DAConfig` NOT done)**
  - New `AnalysisConfig` dataclass (`sakov`, `inflation_states`, `inflation_params`, `jitter_params`, `localisation_matrix`, `pf_resample_threshold`, `pf_jitter_std_param`, `pf_jitter_std_state`). `run_analysis(..., config=None, **legacy_kwargs)`: with no `config` the legacy kwargs are converted by `AnalysisConfig.from_legacy_kwargs` (so old calls keep working); unknown kwargs, or legacy kwargs combined with `config`, raise `TypeError` (before, unknown kwargs were silently forwarded to the inflation filters). Adapters now take the config, the `options` dict and `_option_or_default` (and its "not provided" warnings) are gone.
  - `_DA_analysis` builds one `AnalysisConfig(inflation_states=self.inflation, localisation_matrix=...)` and passes `config=` to both `run_analysis` calls.
  - **Behaviour changes (decided on intent):**
    - `inflation` and `alpha` are the same option (`inflation_states`). Before, `self.inflation` reached only the `enkf_analysis_inflation*` filters (as `alpha`) and was silently ignored by `enkf_analysis_localized_with_inflation`; it is now also its `inflate_states`. No change with the default `inflation=1`.
    - "No localisation matrix" is now `None` (an empty list/array is normalised to `None`). Before, `_DA_analysis` passed `[]`, which made `enkf_analysis_localized_with_inflation` crash (`[] is not None` then `[].shape`) whenever it was used without a localisation matrix.
  - Verified: numerically identical to the previous commit for all DA types (`dev_check_run_analysis_equivalence.py`, 0 differences); `test_run_analysis.py` covers legacy vs config equivalence, `inflation`/`alpha` aliasing, empty-matrix normalisation, inflation in the localized filter, and the `TypeError` cases.
  - `DAConfig` (second half of 5.1) is described in the next entry.

- [x] **5.3 (partial) sections + self-free helpers** (`cathy_DA.py` is now 3 367 lines (3 286 right after `black`); the growth is the new dataclasses/adapters/docstrings; re-check `wc -l` when `run_DA_sequential` is split)
  - File order is now: docstring/imports/constants -> `AnalysisResult`, `AnalysisConfig`, ANALYSIS registry + `run_analysis` -> SMALL HELPERS (`_update_key`) -> PERFORMANCE -> `class DA`. No `from __future__`/circularity: module-level code never calls `DA`.
  - The six performance helpers (`_compute_diff_matrix`, `_compute_rmse`, `_get_rmse_for_sensor`, `_append_to_performance_df`, `_save_performance_to_parquet`, `_load_performance_from_parquet`) are now **module-level functions without `self`** (they never used it). `DA._performance_assessment_pq` stays a method and calls them directly. `test_performance_pq.py` extracts the module-level helpers by AST (still no pyCATHy needed).
  - `_update_key(cycle_nb)` replaces the `"ini_perturbation"` / `"update_nb" + str(n)` logic that was duplicated in `_DA_analysis`, `apply_ensemble_updates` and the parameter-update loop (the literal `"ini_perturbation"` used when creating the ensemble in `prepare_DA` is left as is).
  - **Note:** the GitHub repo has sibling modules `pyCATHY/DA/performance.py`, `observations.py`, `perturbate.py`, `mapper.py`. `performance.py` holds *older* copies of these helpers (functions taking `self`, old `_performance_assessement_pq` logic with the duplicated-rows bug) and is **not imported by this `cathy_DA.py`**. Do not merge them blindly; the fixed versions are the ones in this file.
  - **Not done:** `__all__`, banner comments inside `class DA` (method grouping), `MASKS & CHECKS` and `OBSERVATION MAPPERS` sections (5.5), and moving `_DA_df`/backup helpers; they touch methods that the synthetic tests cannot exercise.

- [x] **Baseline tooling (`baseline_tool.py`)**
  - `capture(da, out_dir)` / `compare(da, baseline_dir, rtol=1e-6)` save and compare the comparable results of one finished DA run: `da.df_DA` (**in memory only, never written by `cathy_DA.py`**, hence the need to capture it explicitly), the `<project>_df_performance.parquet`, every array of `da.dict_parm_pert`, and `da.ET_DA_xr` if a netCDF engine exists. Verified in the sandbox with a fake `DA` object (identical run passes; a 0.1 % change in `df_DA` and a changed parameter value are both reported). Usage and the seed requirement are in the module docstring.
  - **Procedure to follow on a machine with CATHY** (the AI sandbox has no executable):
    1. Check out the ORIGINAL file (`git show <baseline commit>:cathy_DA.py` or your own copy), run one tiny case (3-5 members, 2 observation times, tensiometer only, `np.random.seed(0)` before the perturbation and the run), then `capture(simu, "baseline_original")`.
    2. Keep `baseline_original/` in the repo. After each refactoring step re-run the same script with the new file and call `compare(simu, "baseline_original")`.
    3. Differences are expected for the deliberate bug fixes of this log (step 3.5 maths, `psi`/`sw` fill value, localized-filter parameter orientation, inflation of the localized filter, `param_valid`): capture a **second baseline from the current refactored file** (after checking that its differences with the original are only those fixes) and use that one for the structural steps below.
    4. Upstream reference scripts: `examples/DA/plot_1_DA_NoUni_ic.py` and `pyCATHY/tests/test_DA_Noble.py` in the GitHub repo (they need `doc_test_data` and a prebuilt project, and call `DA.run_DA_sequential` as written for the GitHub version of the class: adapt before use).

- [x] **REAL CATHY BASELINE CAPTURED (in the AI sandbox)**
  - The sandbox can build and run CATHY: `apt-get install -y gfortran liblapack-dev libblas-dev`, `git clone --depth 1 https://github.com/BenjMy/pycathy_wrapper /tmp/pcgh`, `pip install` the Python dependencies (list above); `DA(dirName=..., prj_name=...)` clones the CATHY Fortran sources from `github.com/CATHY-Org/CATHY_src_org` and compiles them with gfortran on first use. One tiny DA case takes about 2-3 minutes.
  - **Case** (`baseline/baseline_case_run.py`, throw-away script; `USE_CONFIG=1 [CLEANUP_VTK=all]` runs it through the new `config=DAConfig(...)` API;, uses only pyCATHY public functions, not part of pyCATHY): default CATHY example mesh, `NENS=4`, EnKF `enkf_Evensen2009`, state-only update (`'St. var.'`), perturbed initial conditions (`ic`, homogeneous, N(-1.5, 0.3)), 2 SWC observations (nodes 5692 and 5000) at t = 0, 3600, 7200 s, `np.random.seed(0/1/2)`. Environment: pandas 3.0.2, numpy 2.4.4, xarray 2026.9.0, 1 CPU. Select the file under test with `CATHY_DA_DIR=<dir containing cathy_DA.py>`, capture with `CAPTURE_TO=<dir>`, compare with `COMPARE_WITH=<dir>`, e.g. `CATHY_DA_DIR=. PYTHONPATH=/tmp/pcgh CAPTURE_TO=new COMPARE_WITH=baseline/base_refactored python baseline_case_run.py` (copy `baseline_tool.py` next to it).
  - **`baseline/base_original/`**: captured with the ORIGINAL uploaded `cathy_DA.py` + two minimal compatibility patches that it needs to run at all here: (1) `selec_atmbc_window`: `VALUE.append(values.item() if values.size == 1 else values)` (NumPy 2.4 raises on `float()` of a 1-element array), (2) `Pool(processes=max(1, cpu_count() - REMOVE_CPU))` (crashes with <= 5 cores). Nothing else was changed.
  - **`baseline/base_refactored/`**: captured with the current refactored file (steps 3.1 -> 5.3, same patches 1-2 already included). **This is the reference for all remaining structural steps.**
  - **Result of the comparison original vs refactored on the real run:** `df_DA`, `dict_parm_pert` and `ET_DA_xr` are **identical**; only `df_performance` differs, exactly as intended by the step 3.5 fixes, and the real run confirms them: the original wrote every row of cycle 0 **twice** (6 rows instead of 4), its `RMSE` is exactly **2x too large** (it divided by the number of observations = 2 instead of the ensemble size = 4: `0.3717` vs `0.1859`), and its `NMRMSE_avg` at cycle 1 was `0.1648` (not a running mean) vs `0.1765 = (0.1883 + 0.1648) / 2`.
  - New in `cathy_DA.py` because of this run: the NumPy compatibility fix (1) above (`selec_atmbc_window` now passes a plain float for single values).

- [x] **5.7 `os.chdir` scoped (NOT fully removed)** , verified on the real baseline case (`compare` with `base_refactored`: `df_DA`, `df_performance`, `dict_parm_pert`, `ET_DA_xr` all identical)
  - New decorator `_restores_cwd` (SMALL HELPERS section, unit-tested incl. the exception path in `test_run_analysis.py`) applied to `run_DA_sequential`, `_run_ensemble_hydrological_model` and `apply_ensemble_updates`: the directory changes they make never leak to their caller or to the user's session any more (before, a DA run left the process inside the last `DA_Ensemble/cathy_N` directory).
  - The `os.chdir(self.workdir)` that was executed inside the loop after every ensemble run is now a single explicit `os.chdir(self.workdir)` before the loop (the callees restore the directory they change, so the loop always runs from the project working directory).
  - `cleanup_vtk` now looks in `<workdir>/<project>/DA_Ensemble/**` explicitly (before: `./**` relative to whatever the current directory happened to be, i.e. a recursive glob from an arbitrary directory). The option is opt-in and was introduced in this log, so no existing behaviour changes.
  - **Why not fully removed:** the remaining 3 `os.chdir(<ensemble member dir>)` calls (in `_run_ensemble_hydrological_model` serial branch and the two member loops of `apply_ensemble_updates`) are needed because the code and the pyCATHY base class address files relative to the current directory: about 10 `os.getcwd()` / `"input/..."` uses in `cathy_DA.py` plus the base-class `update_*` methods (now editable under the relaxed scope rule). Replacing them needs those methods to accept explicit paths. Not exercised by the baseline case: the parameter/atmbc/soil update branches of `apply_ensemble_updates` and the parallel branch.

- [x] **5.8 explicit state (partial)** , verified on the real baseline case (`compare` with `base_refactored`: all four items identical)
  - `_DA_init` now initialises the per-run attributes that used to appear lazily: `self.ET_DA_xr = None` and `self.isET = False` (reset together with `df_DA`). **Behaviour change:** an `ET_DA_xr` left by a previous `run_DA_sequential` on the same object is no longer silently extended by the next run (the counters and `df_DA` were already reset per run).
  - All `hasattr(self, ...)` guards are gone (`ens_valid`, `zone`, `soil_SPP`, `Archie_parms`, `VGN_parms`, `zone3d`, `ET_DA_xr`): same meaning through `getattr(self, name, None) is None`, one idiom everywhere. Values set by the user or by the base class before the DA still win.
  - `isET` is now defined even if no observation time was mapped yet (it was only created in `map_states2Observations`).
  - **Not done:** `EnsembleState` / `DACycle` dataclasses (they would touch ~100 `self.ens_valid` / `self.count_*` uses across methods that the baseline case only partly covers), and moving the remaining attributes set in `prepare_DA` (`inflation`, `localisation`, `verbose`, `use_log_transformed_obs`) into a config (belongs to `DAConfig`).

- [x] **5.1 `DAConfig` (second half)** , verified on the real baseline case through BOTH call styles (`compare` with `base_refactored`: all four items identical)
  - New `DAConfig` dataclass: `inflation`, `localisation`, `threshold_rejected`, `use_log_transformed_obs`, `cleanup_vtk`, `backup_fort777` (validated at construction: an invalid value now fails before a multi-hour run instead of at its end), `verbose`. `run_DA_sequential(..., parallel=True, config=None, **kwargs)` and `prepare_DA(..., parallel, config=None, **kwargs)` take it; with no `config` it is built by `DAConfig.from_legacy_kwargs(kwargs)`, which pops the DA-only keys (`_LEGACY_DA_KEYS`) and emits a `DeprecationWarning`. Every other keyword (`IPRT1`, `TRAFLAG`, `VTKF`, ...) still goes to `run_processor` untouched, and `verbose` is read without being popped because the processor uses it too. Giving the same option both ways raises `TypeError`.
  - The legacy attributes `self.inflation`, `self.localisation`, `self.verbose`, `self.use_log_transformed_obs` are still set in `prepare_DA` (from the config) so no reader had to change; the whole object is also kept as `self.config`. `cleanup_vtk` is read from the config at the end of `run_DA_sequential` (its validation moved into `DAConfig`).
  - `backup_fort777` replaces the hard-coded `self.backupfort777 = False` of `_DA_init` (its branch could never run before). Real run with `backup_fort777=True` (`BACKUP_FORT777=1`): results identical to the baseline and `DAnb<k>fort.777` files written in every member directory, one per cycle.
  - **Real-run checks:** legacy call (`VTKF=2, TRAFLAG=0` only): identical to the baseline, 16 VTK files left in `DA_Ensemble`; `config=DAConfig(inflation=1.0, cleanup_vtk="all")`: identical to the baseline, **0** VTK files left. Unit tests (`test_run_analysis.py`) cover defaults, popping, the `DeprecationWarning`, `verbose` and the validation.
  - **Differences with the plan in section 5.1 (on purpose):** `da_type` and `default_state` stay `run_analysis` / `run_DA_sequential` arguments (they select the filter, they are not options of it); `AnalysisConfig` is built per cycle in `_DA_analysis` from `DAConfig.inflation` (no `DAConfig.analysis` field yet: the localisation matrix is per cycle); `parallel` stays an explicit argument.

- [x] **5.4 split of `run_DA_sequential` (extractions 1-4 of 6)** , verified on the real baseline case run with every touched path switched on (`config=DAConfig(cleanup_vtk="all", backup_fort777=True)`): all four outputs identical to `base_refactored`, 0 VTK files left, 8 `DAnb*fort.777` backups (4 members x 2 cycles)
  - `_validate_prediction(prediction)` (NaN / non-positive check; zero is valid for ET). The printed "Negative or zero values" count is now the number of non-positive, non-NaN entries according to the rule actually applied (it used to count only `< 0`, so zeros were never counted and the ET case was counted with the wrong rule). Unit-tested with a stub `self` in `test_run_analysis.py`.
  - `_log_end_of_time_step(t_atmbc)` and `_log_end_of_da_update()` (the four `console.rule` blocks); the single "end of DA" rule in the `else` branch stays inline.
  - `_save_step_outputs(state, state_analysis, rejected_ens, list_assimilated_obs, list_parm2update)` (`_DA_df`, `_DA_ET_xr`, `backup_fort777`, `backup_results_DA`, `backup_simu`); the re-read of `*_bef_update` when it is empty stays in the loop because the loop's later code may use those variables.
  - `_cleanup_vtk_files(mode)` (replaces the inline block; `mode` validated in `DAConfig`).
  - `run_DA_sequential` went from about 470 to about 400 lines (the rest is dominated by the localisation block).
  - **Not done, and why:** extractions 5 and 6 (the ~130-line localisation loop and `build_obs_node_mask`) and the rest of the target loop body (`_analyse`, `_predict_observations`, `_record_performance`, ...). The localisation branch (`veg_map` / `zones` / `nodes`) is **not exercised by the baseline case**, so moving it would be unverified. Needed first: a second baseline case with `config=DAConfig(localisation=[...])` (needs zones or a vegetation map in the project and a localisation matrix).

- [x] **Second baseline case: states + saturated conductivity (`UPDATE_KS=1`)** , covers the parameter-update branch of `apply_ensemble_updates` / `_update_soil_params_from_perturbations` that case 1 never touched
  - Same tiny case as above but `list_parm2update=["St. var.", "Ks0"]` with a lognormal `Ks` perturbation of zone 0 (scenario names in pyCATHY are case-sensitive: `"Ks"`, not `"ks"`, otherwise the perturbation is silently ignored and the run fails later with `KeyError: 'ks'`; the updated key is then `Ks0`). References: `baseline/base_ks_original/` (original + the 2 compatibility patches) and `baseline/base_ks_refactored/`.
  - **Result original vs refactored:** `df_DA`, `dict_parm_pert` (the updated `Ks` ensembles of every cycle) and `ET_DA_xr` identical; only `df_performance` differs, as in case 1 (intended fixes). The refactored file also passes through the new API (`USE_CONFIG=1`).
  - Run it with `UPDATE_KS=1 CATHY_DA_DIR=. PYTHONPATH=/tmp/pcgh COMPARE_WITH=baseline/base_ks_refactored python baseline_case_run.py` (about 2 minutes). **After every structural step run both cases** (case 1: `base_refactored`, case 2: `base_ks_refactored`).
- [x] **Small fixes found while building case 2** (verified with it)
  - The console message `negative Ks: [] , ens_nb: []` was printed at every cycle even when nothing was negative (loop over an empty list); it now only appears when a value is negative.
  - `DAConfig.localisation` is a **string** (`"veg_map"`, `"zones"`, `"nodes"`); a single-entry list is converted, several entries or an unknown value raise `ValueError`. Before, the list form given in the earlier plan crashed with `UnboundLocalError` inside `localisation.create_mask_localisation` (it compares the argument to a string).

- [x] **Case 3: domain localisation with point sensors (`LOCALISATION=zones|nodes`)** , fixes the `IndexError` of the previous Findings
  - **Code change (`cathy_DA.py`, localisation block of `run_DA_sequential`):** when the observation vector is not one value per surface node (point sensors), `obs_valid` is now `np.isin(mesh_nodes_observed, mesh3d_nodes_valid[loci])`, i.e. a sensor belongs to the zone if its mesh node is one of the (extruded) nodes of that zone; the old node-mask path is kept when the observations cover every surface node (maps). The misleading "NOT IMPLEMENTED YET" message (whose test was inverted) is removed. The substring tests `item in self.localisation` (a string!) became exact comparisons (`self.localisation in ("veg_map", "zones")`).
  - **Verified on the real case:** (a) `localisation="zones"` (the default zone map has a single zone): **identical** to the non-localised baseline `base_refactored` on all four outputs (so the localised branch reproduces the global analysis when the zone covers everything); (b) `localisation="nodes"`: runs through, and only the nodes of the two sensor columns are updated, **32 nodes per member and cycle (2 columns x 16 depth levels) against 7056 without localisation**, the others keep their prior state (the "not all nodes analysed" path). Reference for (b): `baseline/base_locnodes_refactored/` (captured with the fixed file; there is no original equivalent since the original crashes).
  - Run: `USE_CONFIG=1 LOCALISATION=nodes CATHY_DA_DIR=. PYTHONPATH=/tmp/pcgh COMPARE_WITH=baseline/base_locnodes_refactored python baseline_case_run.py` (about 1.5 minutes). **The test set after every structural step is now: case 1 (`base_refactored`), case 2 (`UPDATE_KS=1`, `base_ks_refactored`), case 3 (`LOCALISATION=nodes`, `base_locnodes_refactored`).**
  - `data = data[0]` (open question 2: performance assessment uses only the first zone's data) was unchanged here and **fixed later** (see "Two decisions applied").

- [x] **Case 4: a single observation (`N_SENSORS=1`)** , suggestion 3 of section 12 done
  - Cause: `_get_data2assimilate` returned `np.squeeze(data)`, a 0-d array when there is one sensor, so `_DA_analysis` failed at `len(data)` (`TypeError: len() of unsized object`). Fix: `np.atleast_1d(np.squeeze(data))` (no effect for two or more values).
  - Verified on the real case: one SWC sensor runs through all 3 cycles; case 1 (2 sensors) re-run afterwards is still identical to `base_refactored`. Reference for the one-sensor run: `baseline/base_single_refactored/` (the original crashes, so no original equivalent). Run: `N_SENSORS=1 USE_CONFIG=1 CATHY_DA_DIR=. PYTHONPATH=/tmp/pcgh COMPARE_WITH=baseline/base_single_refactored python baseline_case_run.py`.

- [x] **Case 5: tensiometer observations, negative pressure heads (`OBS_TYPE=tensio`)** , suggestion 2 of section 12 done
  - `_validate_prediction(prediction, list_assimilated_obs=None)` now applies the validity rule **per observation type**: NaN is always invalid; types in the new module constant `_NEGATIVE_VALUES_ALLOWED = ("tensio",)` accept any finite value; ET accepts zero; every other type must be strictly positive. The rule is applied row by row when the prediction has one row per observation (mixed tensio + swc works); when the rows do not match the observations it falls back to "all assimilated types are tensio -> allow negative, else strict". Call site passes `list_assimilated_obs`. Unit-tested (`test_run_analysis.py`: negative accepted for tensio, rejected for swc, mixed row by row, NaN rejected).
  - **Verified on the real case:** 2 tensiometers observing about -1.0 m run through all 3 cycles; the analysis behaves sensibly: ensemble mean at the observed nodes goes from -1.544 m to -0.992 m after the first analysis (observation ~ -1.0 m) and the spread collapses from 0.361 to 0.013. Reference: `baseline/base_tensio_refactored/` (the original rejects these predictions, so no original equivalent). Run: `OBS_TYPE=tensio USE_CONFIG=1 CATHY_DA_DIR=. PYTHONPATH=/tmp/pcgh COMPARE_WITH=baseline/base_tensio_refactored python baseline_case_run.py`.
  - Not covered: mixed tensio + swc in a real run (only unit-tested).
  - **Test set after every structural step is now 5 cases** (each 1.5 - 2 minutes): case 1 `base_refactored`; case 2 `UPDATE_KS=1` / `base_ks_refactored`; case 3 `LOCALISATION=nodes` / `base_locnodes_refactored`; case 4 `N_SENSORS=1` / `base_single_refactored`; case 5 `OBS_TYPE=tensio` / `base_tensio_refactored`.

- [x] **5.4 split of `run_DA_sequential` (extractions 5-6 done)** , verified with **all five real baseline cases** (cases 1-5, all four outputs identical to their references)
  - `DA._analyse(prediction, DA_type, list_parm2update, list_assimilated_obs)` now contains the whole analysis of one cycle: the global branch and the domain-localisation loop (zone masks, per-zone `_DA_analysis`, assembly on the full mesh, nodes without observation keeping their prior). It returns `(ensemble_psi, ensemble_sw, data, analysis, analysis_param)`, the only variables the loop used afterwards (checked with `ast`: free names of the block were `DA_type`, `list_assimilated_obs`, `list_parm2update`, `prediction`, `self` plus the `localisation` module and `np`). The loop now has one call instead of ~180 lines.
  - `build_obs_node_mask(surface_nodes_mask, mesh_nodes_observed, zone_nodes, n_repeat=None)` is a **pure module-level function** (maps: surface mask as is; EM: mask repeated per coil; point sensors: `np.isin` on the zone nodes), unit-tested in `test_run_analysis.py`.
  - Size: `run_DA_sequential` is now about **229 lines** (was about 470 at the start of 5.4); `cathy_DA.py` is 3 577 lines because docstrings, dataclasses and the new helpers were added.
  - Test set: `baseline/run_all_cases.sh` runs the five cases and prints one result line per case (about 8 minutes in total on one CPU; set `CATHY_DA_DIR` to the folder of the file under test and `REFS` to the folder holding the `base_*` references). **Do not pipe it through `head`: the progress output of CATHY is long.**
  - **Not done in 5.4:** `_predict_observations` (the mapping + `_check_prediction_shape` + validation sequence) and `_record_performance` as separate methods; the remaining loop is mostly orchestration of existing helpers, so the gain is smaller than for the pieces above.

- [x] **Case 6: ET observations (`OBS_TYPE=ETact`) + 5.5 partial (`_predict_ET`)**
  - **Bug found by the new case (pandas 3.0.2):** the ET branch of `map_states2Observations` used `series.iloc[list_of_arrays]`, which raises (`ValueError: Buffer has wrong number of dimensions` / `positional indexers are out-of-bounds`) with recent pandas. Fix: flat integer positions `np.hstack(nodes)` (same meaning for older pandas). ET observations use **surface node indices** (0..440 in the default mesh, rows of `fort.777`), not 3D node ids.
  - The ET branch is now `DA._predict_ET(path_fwd_CATHY, obs2map)` (reads `fort.777`, returns `ACT. ETRA` of the last time step at the `ETact` nodes; the no-op expression `df_fort777.loc[...]["ACT. ETRA"]` was dropped). Verified: the ET case run with the extracted method is identical on all four outputs to the run with the inline code plus only the pandas fix (reference `baseline/base_et_refactored/`, captured with that pre-extraction code).
  - **Test set is now 6 cases**, all identical to their references on the current file: `run_all_cases.sh` runs case 1 states, 2 `UPDATE_KS=1`, 3 `LOCALISATION=nodes`, 4 `N_SENSORS=1`, 5 `OBS_TYPE=tensio`, 6 `OBS_TYPE=ETact` (about 11 minutes on one CPU). **Run the cases one by one if your shell kills background jobs** (a detached run stopped after case 4 in the AI sandbox).
  - **Script pitfall fixed:** `baseline_case_run.py` must draw exactly ONE random number per sensor; a version that drew three (one per observation type) changed the observation data and made cases 1-2 differ although the code had not changed. Do not reorder the `rng.normal()` calls.
  - **5.5 not done beyond `_predict_ET`:** the other branches of `map_states2Observations` (tensio / swc are 1-2 line calls into `pyCATHY.DA.mapper`; EM, ERT, discharge, stemflow, scale) were not turned into mapper classes: EM and ERT have **no baseline case** (they need Archie parameters, petrophysics and ERT/EM data), discharge / stemflow / scale only print "Not yet implemented". Build ERT and EM cases first (needs `dict_obs` with `mesh_nodes`, Archie parameters via `set_Archie_parm`) before moving them.
  - Other oddities noticed in that function, left as they are: `if obskey2map != "ET":` compares a list with a string (always true), so psi and sw are always read; the matching is on substrings of the sensor name (`"swc" in obs_key`), not on `data_type`.

- [x] **Case 7: states + porosity of zone 0 (`UPDATE_POROS=1`)** , second parameter family covered before splitting `apply_ensemble_updates` (5.6)
  - `porosity0` is perturbed (N(0.55, 0.05), 4 members) and updated by the DA together with the states; `dict_parm_pert` contains `porosity0/update_nb1` and `update_nb2`. Original (+ the two compatibility patches) vs refactored on this case: `df_DA`, `dict_parm_pert` (including the porosity updates) and `ET_DA_xr` **identical**, only `df_performance` differs (step 3.5 fixes), so the parameter-update branch was not changed by any refactoring step. References: `baseline/base_poros_refactored/` (the one to use) and `baseline/base_poros_original/`.
  - **Test set is now 7 cases** (`run_all_cases.sh`, about 14 minutes on one CPU). Families of `apply_ensemble_updates` still without a case: atmbc, WTPOSITION, van Genuchten, Feddes, Archie.

- [x] **5.6 split of `apply_ensemble_updates` (partial: 3 of the 8 parameter families)** , all **seven** real baseline cases identical to their references afterwards
  - New methods `_update_atmbc_member(dict_parm_pert, ens_nb, key)`, `_update_wtposition_member(cycle_nb, dict_parm_pert, ens_nb, key, shellprint_update)` and `_update_ic_member(cycle_nb, dict_parm_pert, ens_nb, key, shellprint_update)`: the bodies of the `atmbc`, `WTPOSITION` and `ic` branches moved verbatim (done with a script that derived the parameter lists from the free variables of each branch with `ast`, so nothing can be missing; ruff F821 is clean). `apply_ensemble_updates` went from 347 to about 267 lines.
  - **Verification coverage:** the `ic` branch (non-layers, cycle 0) runs in every case; **the `atmbc` branch, the `WTPOSITION` branch and `ic` by layers are NOT exercised by any baseline case**, they are only covered by the static check. Add a case with a perturbed atmbc (`per_name: "atmbc"`, needs `time_variable_perturbation`) and one with `pert_control_name: "layers"` before changing them further.
  - **Not done:** the soil / VG / Feddes / Archie families (`ks`, `porosity`, VG names, Feddes names, Archie names) stay inline: they share the accumulators initialised at the top of the method (`ks_het_ens`, `POROS_het_ens`, `VG_p_het_ens`, `Feddes_withPertParam`, `self.Archie_parms_mat_ens`) and the post-processing after the member loop, so splitting them needs those accumulators to be restructured at the same time (and cases for VG, Feddes and Archie).

- [x] **`DAConfig.seed` and `DAConfig.save_results`** (suggestions 6 and 4 of section 12), both opt-in, verified on the real case (case 8 of `run_all_cases.sh`)
  - `seed`: `np.random.seed(seed)` at the start of `prepare_DA` (the filters draw from the global generator; the perturbation of the ensemble happens before the DA and is not affected). **Verified:** a run with `DAConfig(seed=2)` and no seeding in the script is **identical on all four outputs** to the baseline run whose script calls `np.random.seed(2)` just before `run_DA_sequential`.
  - `save_results`: `_save_step_outputs` writes `<workdir>/<project>/<project>_df_DA.pkl` and `<project>_ET_DA.nc` at the end of every cycle (overwritten, 3 MB / 57 kB for the tiny case), so a crash keeps the finished cycles. **Verified:** the persisted `df_DA` equals the captured baseline one.
  - Both names are in `_LEGACY_DA_KEYS`, so they can also be passed as keywords (deprecated style) without reaching the CATHY processor.
  - **Test set is now 8 runs** (`run_all_cases.sh`: cases 1-7 + case 8 seed/save, about 16 minutes on one CPU; in the AI sandbox run them in groups of two with a plain loop).

- [x] **`DAConfig.analysis`** (suggestion 10 of section 12)
  - `DAConfig.analysis: Optional[AnalysisConfig]`: when given, it is used for every cycle (Sakov form, inflation of states and parameters, jitter, particle filter settings), except that the localisation matrix of the current cycle (`self.localisationMatrix`) wins when there is one; when None the old behaviour is kept (`AnalysisConfig(inflation_states=DAConfig.inflation, localisation_matrix=...)`). Note that with `analysis` given, `DAConfig.inflation` is ignored. Verified on the real case with `enkf_analysis_localized_with_inflation`: `AnalysisConfig(sakov=False)` runs and changes the analysis (max difference 0.16 m of pressure head, all 56 448 node values differ) relative to the default `sakov=True`. Case 1-8 unchanged (the default path is the same code).

- [x] **Pin of the CATHY sources (pyCATHY `cathy_tools.py`) and removal of the fingerprint** (suggestion 5 of section 12; the maintainer allowed this one change outside `cathy_DA.py`)
  - `pyCATHY/cathy_tools.py`: new constants `CATHY_SRC_URL` and `CATHY_SRC_COMMIT = "ef54607df776dbb6f7d974329e5f72a276403d5c"` (HEAD of `main` of `CATHY-Org/CATHY_src_org` on 2026-10-11, last commit dated 2024-05-06) and helper `_clone_cathy_src(dest)`, which fetches exactly that commit (`git init` + `fetch --depth 1 origin <sha>` + `checkout FETCH_HEAD`, no history, no moving branch). `CATHY.__init__` (`version == "1.0.0"`) uses it instead of `Repo.clone_from(..., branch="main")`. The bare `except:` around it (which printed "no internet connection" for any error) is now `except Exception` and prints the real error. The `SCF_variable` / `G. Manoli` versions are not touched. **To upgrade CATHY:** choose a new commit, re-run the baseline cases, change the constant (document it here). Patch: `pycathy_pin_cathy_src.patch` (against `pycathy_wrapper` `55bb7cf`); full file `cathy_tools.py`.
  - **Verified:** a fresh project created with the patched class holds exactly the sources of the pinned commit (SHA-256 over names + contents of `src/`: `4212c121...`, 281 files, identical to a separate checkout of that commit); `tmp_src` is removed afterwards. The sources at the pinned commit are the same as those used for the baselines: 281 source files + about 271 compiled objects = the 552 files the old fingerprint counted after compilation.
  - **Fingerprint removed from `cathy_DA.py`** (it was a workaround for not being able to pin): `cathy_source_fingerprint`, the `import hashlib`, the `self.cathy_src_fingerprint` attribute and the `cathy_src_fingerprint.txt` file written by `prepare_DA`, and its unit test. `cathy_DA.py` is 3 631 lines.
  - **Verified on the real case (case 1, `USE_CONFIG=1`):** the previous `cathy_DA.py` (with fingerprint) and the new one, both on the patched pyCATHY, give **identical** `df_DA`, `df_performance`, `dict_parm_pert` and `ET_DA_xr`; only the old run writes `cathy_src_fingerprint.txt`. Cases 2-8 were not re-run (the only code change in `cathy_DA.py` is the deletion of the fingerprint block). ruff clean, black clean, `test_performance_pq.py` and `test_run_analysis.py` print `OK`.
  - Projects created before the pin keep their own `src/` (the fetch only happens when `src/` is missing); only new projects use the pinned commit.

- [x] **`run_DA_sequential`: loop body split (step 5.4, continued)**
  - New methods `_analysis_cycle(DA_type, list_parm2update, list_assimilated_obs, update_key, parallel)` (map states, validate, analyse, drop invalid members, performance, positivity check, parameter dictionary update) and `_no_analysis_cycle()` (time step without observation). Both return `([psi, sw] before the update, analysis_valid)`; the loop is now: run model, check, `if t_atmbc in ENS_times` one of the two calls, counters, log, `_save_step_outputs`, update inputs.
  - Removed: the local variables that were only passed around (`ens_size`, `sim_size`, `ensemble_sw_valid`), the `ensemble_psi_valid_bef_update = []` sentinel and the "re-read the state if empty" block (in the no-observation step the state is read once and used both as "before" and as "analysis"; the second read was a pure file read of unchanged files), the duplicated `!shortcut here ensemble are not validated!` prints, a stray `print(list_parm2update)` and a dead `pass`. Only console output changed.
  - **Verified** against the file before this step (real runs, `USE_CONFIG=1`): case 1 (states), case 2 (Ks update) and case 3 (`localisation="nodes"`) give identical `df_DA`, `df_performance`, `dict_parm_pert`, `ET_DA_xr`. The no-observation branch is covered by the new **case 9** (`EXTRA_ATMBC=1`: an extra atmbc time at 1800 s without observation; the log shows "No observation for this time", `df_DA` has 3 time steps): identical to the file before this step. ruff and black clean.
  - New baseline case 9 in `baseline_case_run.py` (env `EXTRA_ATMBC=1`) and `run_all_cases.sh` (reference name `base_noobs_refactored`; to create it run once with `CAPTURE_TO`).

- [x] **Logging (step 5.9, suggestion 7 of section 12): every `print()` of `cathy_DA.py` replaced by `logging`**
  - `logger = logging.getLogger(__name__)` and `_configure_logging(verbose)`, called from `prepare_DA`: level INFO by default, DEBUG with `DAConfig.verbose=True`; warnings and errors always shown. A plain stdout handler (message only) is attached **only if neither the module logger nor the root logger has a handler**, so scripts and notebooks that never configure `logging` still see the messages; applications that configure `logging` themselves keep full control (nothing is added, `propagate` untouched).
  - Levels: **warning** (positive pressure heads, invalid predictions with their counts before the `ValueError`, unreadable `mbeconv` / ET files, inconsistent filled X, "Not yet implemented" observation types, the doubtful time index, invalid values before the log transform); **error** (parameter dictionary dumped just before "too many rejected members"); **info** (assimilated observations, parameters to update, particle-filter N_eff / resampling, the zone/layer assumption note); **debug** (domain-check ranges, before/after log transform, `parm size`, Zroot checks, transformation names, ensemble numbers and shapes, valid members, Archie details). Multi-argument prints became `%s` format calls.
  - Removed: the duplicated `print("Archie parameters not defined set defaults")` (the same message is already in `warnings_petro`).
  - The 37 `console.print` calls (rich headings and rules, quiet unless `verbose`) are kept on purpose: they are the UI layer.
  - **Behaviour change (console only):** the diagnostic dumps that used to be printed always are now shown only with `verbose=True`; everything else is shown as before. Results are unchanged.
  - Tests: `test_run_analysis.py` silences the logger and has new checks (the invalid-prediction details are logged as warnings; `_configure_logging` sets INFO / DEBUG and leaves the root logger alone).
  - **Verified:** case 1 and case 9 (real runs) identical to the references; the INFO messages still appear on stdout, the debug ones do not. ruff and black clean; both unit-test scripts print `OK`.

- [x] **CI, `__all__` and the `dictObs_2pd` fix (suggestion 8 of section 12)**
  - **Regression found and fixed.** The "unused imports" cleanup had removed `from pyCATHY.cathy_utils import dictObs_2pd` from `cathy_DA.py`, but `pyCATHY/DA/observations.py` (line 14) and 20+ documentation/example scripts do `from pyCATHY.DA.cathy_DA import dictObs_2pd` (also `mapper`, `localisation`). With the refactored file installed in `pyCATHY/DA/`, `import pyCATHY.DA.observations` would have failed. The baseline harness did not see it (see the caveat below). The import is back with a comment and `# noqa: F401`; `__all__` lists the public names (`DA`, `DAConfig`, `AnalysisConfig`, `AnalysisResult`, `run_analysis`, `build_obs_node_mask`) and the deliberate re-exports (`dictObs_2pd`, `mapper`, `localisation`). A unit test now checks that these names stay importable.
  - **Tests are pytest tests in the repository layout.** `test_run_analysis.py` -> `pyCATHY/tests/test_DA_run_analysis.py` (function `test_run_analysis`, imports `pyCATHY.DA.cathy_DA`, falls back to a loose `cathy_DA.py`, skips under pytest if it cannot import); `test_performance_pq.py` -> `pyCATHY/tests/test_DA_performance_pq.py` (finds `cathy_DA.py` next to itself or in `../DA`). Both still run as plain scripts (`python <file>`) and print `OK`.
  - **Workflow** `.github/workflows/da-quality.yml` (runs on changes to `pyCATHY/DA/**`, `cathy_tools.py` and the two tests): ruff (`F401,F841,F821,F811,B006`), `black --check` on `cathy_DA.py` and the two tests, and the two tests with pytest. Python 3.12 only (3.9 syntax of `cathy_DA.py` was checked with `ast.parse(feature_version=(3, 9))`, but not run). `black==26.10.1` and `ruff==0.17.0` are pinned (formatting changes between black releases). The dependency list was verified in a clean virtualenv: numpy pandas pyarrow xarray matplotlib rich shapely natsort GitPython geopandas rioxarray pyvista imageio ipywidgets scipy seaborn scikit-learn pytest. The workflow itself has not been run on GitHub (only its commands, locally).
  - **Verified:** in a scratch copy of the repository with the refactored `cathy_DA.py` and patched `cathy_tools.py` installed in place: `import pyCATHY.DA.observations`, the documentation imports, `pytest` (2 passed) and both scripts; case 1 run through the repository's own `pyCATHY.DA.cathy_DA` (not `CATHY_DA_DIR`) identical to the reference.
  - **Caveat for the baseline harness:** with `CATHY_DA_DIR` the refactored file is loaded as a top-level module, while `pyCATHY.DA.observations` still imports the *repository's* `pyCATHY.DA.cathy_DA`. A broken import path of the refactored file is therefore invisible. Before delivering, always run one case **without** `CATHY_DA_DIR` after copying the file into `pyCATHY/DA/`.

- [x] **5.7 continued: `os.chdir` only through `_working_directory` (and one in `run_DA_sequential`)**
  - New context manager `_working_directory(path)` (restores the directory also on error); `_restores_cwd` is now built on it. The two member loops of `apply_ensemble_updates` run each member inside `with _working_directory(<member dir>):` (the pyCATHY `update_*` methods and the `os.getcwd()` / `"input/..."` uses still need the member directory, so the loop bodies stay as they were, only indented). The serial branch of `_run_ensemble_hydrological_model` no longer changes directory at all: `subprocess.run(..., cwd=member_dir)`.
  - The `_restores_cwd` decorator is removed from `_run_ensemble_hydrological_model` and `apply_ensemble_updates` (nothing leaks any more); it stays on `run_DA_sequential`, which keeps its single explicit `os.chdir(self.workdir)` before the loop. After the member loops the process directory is now the caller's one instead of the last member directory (checked: nothing between/after the loops depends on it).
  - **`pyCATHY/DA/observations.py` fixed at the source** (new scope rule): `from pyCATHY.cathy_utils import dictObs_2pd` instead of importing it through `cathy_DA` (which also removes an `observations` -> `cathy_DA` import cycle). `cathy_DA` keeps the re-export for the documentation and user scripts. File `observations.py` and the updated `pycathy_pin_cathy_src.patch` (now two files: `cathy_tools.py`, `observations.py`) are in the outputs.
  - New baseline case 10 (`SERIAL=1`, `parallel=False`) in `baseline_case_run.py` / `run_all_cases.sh`: the serial run branch had no coverage.
  - **Verified** (real runs, file before this step vs after, `USE_CONFIG=1`): case 10 (serial), case 2 (Ks), case 7 (porosity), case 1 (states), case 9 (step without observation): identical `df_DA`, `df_performance`, `dict_parm_pert`, `ET_DA_xr`. Not covered by any case: the atmbc / ic-by-layers / VG / Feddes / Archie branches inside the member loops (their bodies are unchanged apart from the indentation). Unit test for `_working_directory` added to `test_DA_run_analysis.py`; ruff and black clean.
  - **Tip:** the baseline runs write ~115 MB each; clean the work directories after each comparison (the sandbox disk filled up once).

- [x] **5.6 `apply_ensemble_updates` split (+ baseline cases 11-13, `read_grid3d` fix)**
  - `apply_ensemble_updates` keeps the argument handling and delegates: `_update_states_from_analysis` (writes the analysed pressure heads into `input/ic`; the echo is for the first valid member only, as before), a double loop over keys and members that calls `_update_parameter_member(ctx, key, key_root, ens_nb)` (the dispatch: atmbc / WTPOSITION / ic / Ks / porosity (+ Archie) / VG / Feddes / Archie), `_update_feddes_member` (the only branch that was still inline), `_member_dir(ens_nb)`.
  - The four accumulators that lived as local lists across keys and members (`ks_het_ens`, `POROS_het_ens`, `VG_p_het_ens`, `Feddes_withPertParam`) and the values the branches need are in a small dataclass `_EnsembleUpdate` (`cycle_nb`, `update_key`, `dict_parm_pert`, `zone3d`, `ks`, `porosity`, `vg`, `feddes`). The name lists are module constants (`_VG_PARM_NAMES`, `_ARCHIE_PARM_NAMES`, `_FEDDES_PARM_NAMES`, tuples). `shellprint_update` was `True` for every member of the parameter loop (it was only reset after the member loop): the branches now get the constant `True`.
  - **The dispatch conditions are kept verbatim**, including the substring tests (`name.casefold() in "ks"`, `in "porosity"`, `in "atmbc"` ...): see the finding below.
  - **New baseline cases (real runs)** in `baseline_case_run.py` / `run_all_cases.sh`: 11 `PARM_CASE=vg` (states + `n_VG0`), 12 `PARM_CASE=feddes` (states + `ZROOT0`), 13 `PARM_CASE=wtpos` (`WTPOSITION` + states). All three update their parameter at every cycle (checked in `dict_parm_pert`). Case 14 `PARM_CASE=atmbc` exists in the script but **does not run** (see "Checks to do").
  - **Verified** (file before this step vs after, real runs, `USE_CONFIG=1`): cases 11, 12, 13 (references captured with the file before the split), plus cases 1, 2 (Ks), 3 (`localisation="nodes"`), 7 (porosity), 9 (step without observation), 10 (serial) against their references: **all 9 comparisons identical** (`df_DA`, `df_performance`, `dict_parm_pert`, `ET_DA_xr`). Not covered: the atmbc branch and the Archie-only branch. ruff and black clean.
  - **`_read_state_ensemble` fallback fixed**: it called `in_CT.read_grid3d` (does not exist in `cathy_inputs`); it now reads `output/grid3d` with `out_CT.read_grid3d` like the other fallback. Dead code in normal runs (`grid3d` is read earlier), so no result changes.
  - **`pyCATHY/DA/perturbate.py` (upstream bugs, other file touched under the relaxed scope rule)**: `np.Inf` -> `np.inf` (removed in NumPy 2; broke every VG perturbation) and `parm['pert_control_name']` -> `parm.get('pert_control_name')` (a `KeyError` for the WTPOSITION entry, which has no such key). File `perturbate.py` and the updated `pycathy_pin_cathy_src.patch` (now `cathy_tools.py`, `observations.py`, `perturbate.py`) are in the outputs.

- [x] **`_check_before_analysis` split**
  - `_member_rejection_reason(n)` (returns why member `n` cannot be used, or `None`: empty `mbeconv`, missing cumulative values, run stopped before the last printing time of the window; raises one of `_READ_ERRORS` if the file cannot be read), `_raise_if_too_many_rejected(rejected, threshold)` (the threshold test and the `ValueError`), and a short loop in `_check_before_analysis`. Messages are unchanged.
  - **One ordering fix:** the `len(df_mbeconv) == 0` test was unreachable (it came after `iloc[-1]`, which raises `IndexError` on an empty frame and was reported as "cannot read mbeconv"); it is now tested first. The member is rejected in both cases; only the message of an empty file changes.
  - **Unit test** (`test_DA_run_analysis.py`, with a patched `out_CT.read_mbeconv`): good run, NaN cumulative values, run stopped early, empty file, unreadable file, member not in `ens_valid`, and the threshold (`ValueError` with the percentage). Real runs only reach the "stopped early" branch (case 14).
  - **Verified** (real runs, file before vs after): cases 1 (states), 2 (Ks), 9 (step without observation) identical. ruff and black clean.

- [x] **`_check_after_analysis` rewritten as a rule function**
  - The five near-identical branches (and the unused `id_valid` lists, and the message loop that re-printed the indices of *earlier* parameters against the values of the current one) became `_nonphysical_values(name, values, root_depth_limit)` (module level; returns `(mask, label)` or `None`) and a short loop that collects the invalid members. `_max_root_depth()` (thickness of the 3d mesh, only read for a root depth). Rules, unchanged: `rFluid` < 0; `porosity` outside [0, 1]; `a_Archie` outside [0, 3]; `Ks` < 0; `PCREF` > 0; `Zroot` deeper than the mesh. Comparisons are strict (a value on a bound is accepted: the old comment "strictly between 0 and 1" was wrong) and NaN is not flagged; names are matched by substring in the same order as before.
  - **Console messages changed** (only those): one message per parameter with invalid members, naming the parameter and its values; nothing printed when all members are valid.
  - **Verified:** an old-vs-new comparison on 400 random inputs (all rule families, NaN, values on the bounds, random parameter subsets): 0 differences in the returned set of valid members; unit tests for each rule, the union over parameters, NaN, and the lazy mesh access; real runs (file before vs after) identical for cases 2 (Ks), 7 (porosity), 12 (Feddes `ZROOT0`, uses the real root-depth limit) and 1 (states). ruff and black clean.

- [x] **5.8 (part): `DA.__init__` and explicit DA state**
  - `DA` had no `__init__`: its own attributes appeared whenever some method first assigned them and four reads were guarded with `getattr(self, name, None)`. New `DA.__init__(*args, **kwargs)` (forwards everything to `CATHY.__init__`) calls `_init_da_state()`, which defaults `Archie_parms`, `VGN_parms`, `localisationMatrix`, `ens_valid` (all `None`, they may be set by the user before the run) and the per-run state (`dict_parm_pert`, `df_DA`, `df_Archie`, `ET_DA_xr`, `isET`, `localisationBool`, `Archie_parms_mat_ens`, `count_atmbc_cycle`), which `_DA_init` still resets at every run. The four `getattr(self, ..., None)` guards became plain `is None` tests.
  - **Deliberately not defaulted:** `dict_obs` and `count_DA_cycle`, which `CATHY.__init__` already defines. `CATHY` tests `count_DA_cycle is not None` (in `update_ic`, `update_soil`, `update_atmbc`, ...) to know whether a DA is running and to name its backup directories: defaulting it to 0 at construction would have changed those calls before any DA. A unit test asserts it stays `None`. The guards on attributes that belong to the parent class (`zone`, `soil_SPP`, `zone3d`) are kept.
  - Not done from 5.8: grouping the fields in dataclasses; `isET` is still set in `map_states2Observations` and read in `run_DA_sequential` (but it is now defaulted).
  - **Verified:** unit test of `DA.__init__` (patched `CATHY.__init__`: arguments forwarded, defaults, `count_DA_cycle` untouched); real runs (file before vs after) identical for case 6 (`OBS_TYPE=ETact`, uses `isET`), case 7 (porosity, uses `Archie_parms`) and case 1. ruff and black clean.

- [x] **5.5 `map_states2Observations` split by role**
  - `map_states2Observations` now selects the observations once (`_obs_key_select` is pure and was called again for every member), sets `isET`, loops over the valid members calling `_predict_member(ens_nb, obskey2map, obs2map)` (reads the member soil and last state, applies the mapper of each observation type: tensio / swc / ETact (`_predict_ET`) / EM; "Not yet implemented" warnings for stemflow, scale, discharge), checks the shape, then adds ERT. ERT: `_ert_ensemble_inputs()` (paths and mesh-node porosities of the valid members, parallel only) and `_map_ERT(...)` (messages, `mapper._map_ERT_parallel`, merge of `df_Archie`, stacking under the other observations).
  - The per-type `if` blocks are kept as independent `if`s (not `elif`), as before; the soil is still read for every member whatever the types.
  - **Behaviour changes, both on paths that did not work:** (1) the ERT preparation was guarded by `if "ERT" in obs_key`, where `obs_key` was the loop variable left over from the previous loop, i.e. the *last* observation: with ERT not last, `ensemble_fwd_paths` was undefined (`NameError`). It now tests "any ERT observation". (2) ERT without `parallel=True` also ended in a `NameError` (the debug lines used the undefined arrays); it now raises `NotImplementedError("ERT observations are only mapped with parallel=True")`. Also removed: the test `obskey2map != "ET"` (a list compared with a string: always true, the state was always read), the duplicated path/soil variables and the unused `POROS_mesh_cell_ensi`.
  - **Kept as it was (probable bug, see findings):** the ERT mapping is repeated for every observation key that contains "ERT" (`for obs_key ...: if "ERT" in obs_key`), so two ERT keys at the same time would stack the same predictions twice.
  - **Verified:** a unit test with substituted mappers (tensio + swc column order and values; ET first; EM called with the member path and porosity; ERT in parallel appended below the others, with ERT first or last, `df_Archie` merged; the `NotImplementedError`); real runs (file before vs after) identical for case 1 (swc), case 5 (tensiometers) and case 6 (ETact). **EM and ERT themselves are still not run for real** (no case: ERT needs the forward model dependencies). ruff and black clean.

- [x] **Suggestion 9: type hints and `pyproject.toml` settings**
  - `from __future__ import annotations` (keeps the syntax valid for Python 3.9, checked with `ast.parse(feature_version=(3, 9))`) and type hints on the public pieces (`run_analysis`, `AnalysisResult.diagnostics: Optional[dict]` (was `dict = None`), `build_obs_node_mask`, `_update_key`) and on every helper written during the refactoring (`_working_directory`, `_restores_cwd`, `_configure_logging`, `_warn_once`, `_nonphysical_values`, and the `DA` methods `__init__`, `_init_da_state`, `_analysis_cycle`, `_no_analysis_cycle`, `_check_before_analysis`, `_member_rejection_reason`, `_raise_if_too_many_rejected`, `_check_after_analysis`, `_max_root_depth`, `_member_dir`, `_update_states_from_analysis`, `_update_parameter_member`, `_update_feddes_member`, `_predict_member`, `_ert_ensemble_inputs`, `_map_ERT`). The attributes defaulted to `None` in `_init_da_state` are annotated (`Archie_parms: Optional[dict]`, `ens_valid: Optional[Sequence[int]]`, ...). `DAConfig` / `AnalysisConfig` fields were already annotated.
  - **`pyproject.toml`** (of the pyCATHY repository, which only had `[build-system]`): `[tool.black]` (line length 88, py39) and `[tool.ruff]` / `[tool.ruff.lint]` (`select = F401, F841, F821, F811, B006`). `ruff check pyCATHY/DA/cathy_DA.py` and `black --check ...` need no command-line options any more (checked); `.github/workflows/da-quality.yml` uses the file for the ruff rules (the tool versions stay pinned in the workflow). The selection only matters when ruff is run on the repository; nothing runs it automatically on the other files.
  - **mypy (informational, not enforced):** `mypy --ignore-missing-imports --follow-imports=skip cathy_DA.py` reports 7 errors, all reads of the `Optional` attributes `ens_valid` and `Archie_parms` inside a run (they are set by `_DA_init` / `_mapping_petro_init` before use). Making them non-optional would need either an `assert` at each use or a different initialisation; not done.
  - **Verified:** annotations do not change runtime behaviour; unit tests, ruff, black and the real case 1 (identical to the reference) after the last edit.

- [x] **`_DA_analysis` split (327 -> 127 lines) + baseline case 15 (`LOG_OBS=1`)**
  - New methods: `_data_cov_of_cycle(n_data)` (stacked covariance of the cycle, size check), `_analysis_config_of_cycle()` (the user's `AnalysisConfig`, or the default built from the inflation, completed with the localisation matrix of the cycle), `_log_transform_obs(...)` (log10 of observations and predictions: value ranges, warning for non-positive predictions, histogram), `_save_obs_pred_boxplot(...)`, `_da_ensemble_file(prefix)` (path of a file of the cycle in `DA_Ensemble`, was written out three times), `_plot_analysis_diagnostics(...)` (covariance matrices; a failure of the plot only prints a message), and the module function `_log_domain_check(...)` (was nested; its commented-out threshold checks are removed, it only logs).
  - `_DA_analysis` itself: state and data, covariance and config, valid members / observations, observations as seen by the filter (log or not), `run_analysis`, diagnostics, back-transformation of the parameters.
  - **Behaviour:** none on the results. Output only: the dead second call `_get_data2assimilate(...)` (result discarded; it only logged "Assimilated Observations are" again) and the duplicated `logger.info` are removed; the two diagnostic figures are now **closed** after saving (`plt.close(fig)`: they were never closed, one figure kept in memory per cycle and observation type); the plotting `except` names the exception in its message.
  - **New baseline case 15** (`LOG_OBS=1`, `use_log_transformed_obs=True` in `DAConfig`; swc observations): the log-transform branch had no real run. Reference captured with the file before the split; case added to `baseline_case_run.py` and `run_all_cases.sh`.
  - **Verified:** real runs, file before vs after, identical for case 15 (log), case 1 (states), case 3 (`localisation="nodes"`), case 2 (Ks); unit tests for `_data_cov_of_cycle` and `_analysis_config_of_cycle` (default config, legacy matrix, own config kept, own config + matrix of the cycle). ruff and black clean.
  - **Practical note:** two baseline runs at the same time exceed the 4 GB of the sandbox (a run was killed, exit 137); run the cases one after the other.

- [x] **`_analyse` split (178 lines -> a 15-line dispatch + 5 methods)**
  - `_analyse` sets `localisationBool` and dispatches to `_analyse_global` (no localisation: all observations and nodes valid) or `_analyse_by_zones` (domain localisation: zone mask, one `_DA_analysis` per zone that contains observations, results assembled on the whole mesh). Helpers: `_zone_parameters(list_parm2update, loci)` (state + the zone's own parameter for `veg_map` / `zones`, all parameters for `nodes`) and `_assemble_localised_analysis(analysis_with_localisation, ensemble_psi)` (zone analyses sorted by node index; the nodes that no zone analysed keep the state read from the ensemble).
  - `get_mesh_mask_nodes_observed` (pure) and the EM repeat count are computed once before the zone loop instead of in every iteration.
  - **Behaviour change on a path that did not work:** when no observation lies in any zone the old code failed with an unrelated `IndexError` (`data[0]` of an empty list, or an unbound variable); it now raises `ValueError("no observation lies in any '<mode>' localisation zone: nothing to analyse")`. The returned `ensemble_psi` / `ensemble_sw` are still those of the last analysed zone, and only the data of the first zone is returned (the existing "ONLY TAKE THE first part of the data?" doubt is kept: performance assessment with localisation still needs a decision).
  - **Verified:** unit tests (zone parameters for the three modes; two zones assembled in node order; a sensor in one zone only, with the other nodes keeping the prior; no sensor in any zone; no localisation -> global analysis with every observation valid); real runs (file before vs after) identical for case 1 (global), case 3 (`localisation="nodes"`) and a new variant of it with one sensor (`LOCALISATION=nodes N_SENSORS=1`). **Not reached by any real run:** the "nodes not analysed keep the prior" branch (the zones of a `nodes` localisation cover the whole mesh in these cases; the branch is covered by the unit test) and the `veg_map` / `zones` modes. ruff and black clean.

- [x] **`_update_soil_params_from_perturbations` split**
  - The method was long mostly because of a 60-line docstring (with wrong statements: `shellprint_update` is a flag passed to `update_soil`, not "a function, currently unused"); it is rewritten and the logic split in three: `_SOIL_PARM_COLUMNS` (module constant: columns of the soil table set by `Ks`, `porosity`, `n_VG`, `thetar_VG`, `SATCELL_VG`), `_assign_soil_value(df, pert_control_name, index, update_cols, value, veg_map, zone)` (module function, pure: where the value goes for `zone` / `layers` / `root_map` / everywhere), `_soil_tables_to_fill(update_cols)` (per-member soil tables with the columns emptied) and `_write_member_soil(df, pert_control_name, shellprint_update)` (soil file; for layers also the porosity mapped to the mesh). `if contains_nan == False` became `if not df.isna().any().any()`.
  - **Rule kept (and now tested):** the soil file of a member is only written when no value is missing any more, i.e. by the call that fills the last zone / layer.
  - **Behaviour:** unchanged.
  - **Verified:** unit tests for the four ways of assigning, and for the write-when-complete rule (two zones: nothing written after the first, one write with both zones after the second; the three permeability columns set by `Ks`; unknown parameter raises); real runs (file before vs after) identical for case 2 (Ks, zone), case 7 (porosity) and case 11 (`n_VG`). **Not reached by any real run:** `pert_control_name` equal to `layers` (its porosity-to-mesh mapping) and `root_map`. ruff and black clean.
  - **Environment note:** the covariance figure of `_plot_analysis_diagnostics` (matrices of 7057 x 7057) now gets the sandbox killed (exit 137) at "Plotting COV matrices", also with the file *before* this change, so it is not caused by it (the same runs worked earlier). `baseline_case_run.py` has a new switch `NO_COV_PLOT=1` that replaces only `show_DA_process_ens` by a no-op; the numbers are not affected. Use it on machines with less than ~4 GB.

- [x] **`run_DA_sequential`: one time window in `_run_window` (5.4, finished)**
  - New dataclass `_RunOptions` (`DA_type`, `list_parm2update`, `list_assimilated_obs`, `update_key`, `parallel`, `callexe`, `threshold_rejected`: the settings of one call, shared by all windows) and method `_run_window(t_atmbc, options)`: run the ensemble, drop the rejected members, `_analysis_cycle` if there is an observation at `t_atmbc` (else `_no_analysis_cycle`), record the step, update the inputs for the next window (not after the last one). `run_DA_sequential` is now: configuration, `prepare_DA`, first input update, `for t_atmbc ...: self._run_window(...)`, vtk clean-up (93 lines, 50 of them docstring).
  - **Behaviour:** unchanged.
  - **Verified:** unit test of `_run_window` (call order for a window without observation; window with observation; rejected member dropped; last window does not update the inputs and prints the end rule); real runs (file before vs after, `NO_COV_PLOT=1`) identical for case 1, case 9 (window without observation) and case 10 (serial). ruff and black clean.

- [x] **Two decisions applied: performance with localisation, and one ERT mapping per cycle**
  - **Localisation returned the data of the first zone only** (`data[0]`), while `prediction` covers all the observations: the performance `|data - prediction|` then broadcast one datum over all the predictions (silently wrong with 1 observation in the first zone) or raised a broadcast `ValueError`. Evidence: in the saved references (same observations) `RMSE_avg` equals the mean of the per-sensor RMSEs without localisation (0.188253 at t=0) but not with it (0.185873). Fix: `_analyse_by_zones` returns **all** the observations of the cycle (`_get_data2assimilate`), as the global analysis does (the per-zone data are not needed; the returned `ensemble_psi` / `ensemble_sw` of the last zone are the unfiltered state read by every zone, so identical for all). Guard: `_compute_diff_matrix` raises `ValueError` when the number of observations differs from the number of predictions (it never broadcasts one datum over all rows).
  - **Effect on results:** only the `RMSE_avg` and `NMRMSE_avg` columns of `df_performance` of localised runs with more than one observation change (case 3: t=0 now 0.188253 = global value = mean of the per-sensor RMSEs; t=1 0.171915); `df_DA`, `dict_parm_pert` and `ET_DA_xr` are identical. Case 16 (one sensor) unchanged. **The reference of case 3 was replaced.**
  - **ERT was mapped once per ERT key**, but `mapper._map_ERT_parallel` ignores the key: it takes the cycle's entry (`dict_obs[...]["ERT"]`), so two keys repeated the same forward model and stacked identical predictions twice. Now: one mapping per cycle; two keys containing "ERT" at the same time raise `ValueError("only one ERT survey per assimilation time is supported, got [...]")`. No change with a single ERT key.
  - **Related, not changed:** `mapper._map_EM` has the same structure (the entry of the cycle, whatever the key) and `_predict_member` calls it once per EM key: with two EM keys the EM prediction would be stacked twice. Needs a real EM case before changing it (see "Checks to do").
  - **Verified:** unit tests (zones return all the data; diff-matrix guard for 1 and 3 observations vs 4 predictions; ERT: one forward model per cycle, two ERT keys raise); real runs, **identical to their references**: cases 1, 5 (tensiometers), 6 (ET), 9 (window without observation), 15 (log observations), and case 3 against its **new** reference (only `RMSE_avg` / `NMRMSE_avg` differ from the old one); acceptance check on the new case 3: `RMSE_avg` equals the mean of the per-sensor RMSEs at every time. ruff and black clean.

### Findings not yet fixed

- **Diagnostic plots are silently skipped with the localized filter**: the run prints `Impossible to plot matrices (ValueError: shapes (7056,4) and (2,4) not aligned ...)` because `enkf_analysis_localized_with_inflation` returns `dD` / `dAS` / `B` with other shapes than the plain EnKF filters (`show_DA_process_ens` assumes the latter). The run itself is not affected (the plotting is in a `try`). Either adapt the diagnostics in the adapter or skip the plot for that filter with an explicit message.

- **Updated parameters and their bounds (corrected analysis):** the scenario bounds `clip_min` / `clip_max` stored in `dict_parm_pert` are only used when the ensemble is *generated*; after an analysis `_check_after_analysis` validates members with hard-coded physical rules instead (Ks > 0, PCREF < 0, `a_Archie` in (0, 3), rFluid > 0, root depth within the mesh) and **rejects** invalid members (they leave `ens_valid`) rather than clipping them. In case 7 the updated porosity reaches 0.845 > `clip_max` 0.7 and is accepted by design. **Fixed:** the porosity rule only rejected negative values; it now requires 0 < porosity < 1 (a volume fraction), unit-tested and without effect on cases 1-7. Open design question: should the scenario bounds also be enforced after an update (reject or clip)? It would change case 7 (members above 0.7 would be rejected).

- **Domain localisation with point observations: FIXED** (see "Case 3" in the log). Remaining caveat found while fixing it: the loop uses `mesh3d_nodes_valid[loci]` where `loci` enumerates `np.unique(mask_surface_nodes)` **including** `-9999`, while `mesh3d_nodes_valid` is built **without** `-9999`; if a mask contains `-9999` (cells outside the catchment) every zone index is shifted by one. Not triggered by the baseline cases (no `-9999`); use `node_value` to select the zone instead of `loci` when this is addressed.
- `id_nonvalid` mixes shapes (list of index lists) in the post-analysis check: **FIXED** by the rewrite of `_check_after_analysis` (see "`_check_after_analysis` rewritten" in the log).

- **Tensiometer observations: FIXED** (see Case 5 in the log).
- **A single observation: FIXED** (see Case 4 in the log).

- **Substring tests in the dispatch of `apply_ensemble_updates`** (kept as they were): `key_root[0].casefold() in "ks"` (also `in "porosity"`, `in "atmbc"`, `in "WTPOSITION"`, `in "ic"`) is a *substring* test, not an equality test. A key such as `"k"`, `"s"`, `"por"` or `"c"` is silently routed to the Ks / porosity / ic branch instead of raising "key to update is not existing". Intended is `==`. Changing it is a (tiny) behaviour change: do it separately, with a test.
- **`atmbc_pert_rules` (perturbate.py) gives NaN when a time step is larger than `time_decorrelation_len`**: `gamma = 1 - dt/Tau` is negative below -1 for the padded last interval (`atmbc_times[-1] + 86400`) and `sqrt(1 - gamma**2)` is NaN (checked by calling the function: `Tau=3600` -> NaN, `Tau=864000` -> finite). The AR(1) coefficient also uses the interval *after* each time instead of the one before. Not changed (scientific formula); a decision is needed (`gamma = exp(-dt/Tau)`?).

- `pf.particle_filter_analysis` cannot run a state-only update: with no parameters it fails (`zero-size array to reduction operation maximum`). `DA_type="pf"` therefore requires at least one updated parameter. Decide later whether to guard (clear error) or support state-only PF.
- (`Amean`/`MeasAvg` of the localized filter have shape `(n, 1)` instead of `(n, n_members)`: harmless, they are not used by `_DA_analysis`; only `COV`, `dD`, `dAS`, `B` are plotted.)

- **ERT mapping repeated per ERT key**: **FIXED** (see "Two decisions applied" in the log).

- **`run_DA_smooth` is an unfinished stub** (kept): it runs `prepare_DA`, maps the states, reads the state ensemble, calls `_DA_analysis` (without `obs_valid` / `obs_mesh_nodes_valid`) and ends with `pass`: no check after the analysis, no update of the inputs, nothing returned, and no other file of the repository uses it. Decide whether to finish it (the smoother needs the whole window run at once) or to remove it.

- **`_map_EM` per EM key** (same pattern as the ERT bug, not changed): `mapper._map_EM` takes the EM survey of the cycle whatever the key, `_predict_member` calls it for every key containing "EM": two EM keys at the same time would stack the same prediction twice. Confirm with a real EM run, then apply the same rule (one EM survey per assimilation time, else `ValueError`).

### Checks to do (not blocking the refactoring)

- **Updating `atmbc` parameters inside a DA run rejects 100 % of the members (case 14, `PARM_CASE=atmbc`).** Mechanism, seen in a real run and reproduced with the `cathy_DA.py` received at the start of the work (so it is **not** a regression of the refactoring): `_update_input_ensemble` calls `selec_atmbc_window()` (window 0-3600 s, which also sets `TIMPRT` / `TMAX` of `self.parm`) and then `apply_ensemble_updates`, whose `_update_atmbc_member` rewrites the member `input/atmbc` with the **whole** perturbed series (0-7200 s) through `update_atmbc`, and sets `self.parm["(TIMPRT(I),I=1,NPRT)"]` to 7200 s. `_check_before_analysis` then compares the last CATHY output time (3600 s) with that 7200 s minus `DELTAT` and rejects every member (`df_mbeconv['time']3600.0`). To decide: should `_update_atmbc_member` write the windowed values (or only update the dictionary and let `selec_atmbc_window` write the files)? Needs a reference result before any refactoring of the atmbc branch. In the baseline script the scenario for atmbc is a log-normal **multiplier** (`per_nom` = 1.0, `per_sigma` = 0.1: a negative nominal gives `log(<0)` = NaN) and needs `run_processor(IPRT1=3, DAFLAG=0)` + `read_inputs("atmbc")` before `perturbate` (they build `atmbc["atmbc_df"]`); the script also stops early with a clear message when a perturbation array is not finite.
- The atmbc branch (`_update_atmbc_member`) and the Archie-parameter-only branch (`_ARCHIE_PARM_NAMES` other than `porosity`) have no baseline case; `selec_atmbc_window` is covered only without atmbc parameters.


- `run_DA_smooth` has no `cleanup_vtk` and does not loop; kept as experimental (Decided item 2).

### Findings from the GitHub source (resolves open question 1, raises a new one)

- **Open question 1 resolved:** in `pyCATHY/DA/enkf.py` (GitHub `main`), `enkf_analysis_localized_with_inflation(data, data_cov, ensemble, param, predict_obs, L=None, **kwargs)` takes `ensemble` **before** `param`. The call in `run_analysis` is therefore **correct, not a bug**. Do not "fix" the order. Use keyword arguments if the call is ever rewritten.
- **New problem:** `enkf.enkf_analysis_localized` **does not exist** in GitHub `main` (only `enkf_analysis_localized_with_inflation` does). The `DA_type == "enkf_analysis_localized"` branch in `run_analysis` would raise `AttributeError`. Decision needed: remove the branch, or route it to `enkf_analysis_localized_with_inflation` with inflation = 1.0 and no jitter. Left untouched for now.
- `enkf_analysis_localized_with_inflation` does `kwargs.pop('Sakov')` with no default, so `Sakov` must always be passed (`run_analysis` does).
- `enkf.enkf_analysis` defaults to `Sakov=False`, while `run_analysis` passes `Sakov=True` only for the `_Sakov` variants (consistent).

### Next steps (in order)

1. ~~Capture the baseline~~: done (see log). After **every** structural step run the tiny case on the new file and `compare` with `baseline/base_refactored` (about 3 minutes); it must pass with no difference.
2. Baseline cases 1-13 and 15 exist (see log; case 14 `PARM_CASE=atmbc` does not run: see "Checks to do"). Remaining structural work needs **new cases first**: a real EM and ERT run (5.5 is split and unit-tested with substituted mappers only), atmbc (see the check) and ic-by-layers. Optional without new cases: `_predict_observations` / `_record_performance` (rest of 5.4); dataclasses for the DA state (rest of 5.8). One change at a time; run the cases that touch it after each. No suggestion of section 12 is left.
3. Open question 2 (localisation with several zones: `data = data[0]` for performance assessment) before touching the localisation block.
4. Still possible without CATHY (low value): method-group banner comments in `class DA`, more unit tests for pure pieces (`_from_enkf`, `AnalysisConfig`).
5. Tooling note: before every commit run (from the repository root, file in `pyCATHY/DA/`) `black pyCATHY/DA/cathy_DA.py`, `ruff check pyCATHY/DA/cathy_DA.py --select F401,F841,F821,F811,B006` and `pytest pyCATHY/tests/test_DA_run_analysis.py pyCATHY/tests/test_DA_performance_pq.py`; the same checks run in `.github/workflows/da-quality.yml`. Note that black rewrites `#%%` into `# %%`.


---

## 12. Suggested improvements (not requested; ranked by value / risk)

Everything here is optional. Each item says what was observed, the proposed change and how to verify it. Only `cathy_DA.py` should be modified (scope rule).

1. **DONE (simpler variant, see Case 3)** , **Localisation for point observations** (observed: `IndexError`, see Findings). Map every observation to its surface node (`node_id % nnod`, to be confirmed by comparing `grid3d["mesh3d_nodes"][id][:2]` with `[id % nnod][:2]`) and build `obs_valid[i] = mask_surface_nodes.ravel()[surface_idx[i]] == node_value`; keep the current behaviour when the observations already cover all surface nodes. Pure function `build_obs_node_mask(...)` with unit tests, then verify with a baseline case using `localisation="nodes"` and 2 sensors (case 3).
2. **DONE (see Case 5)** , **Tensiometer data** (negative pressure heads) were rejected by `_validate_prediction`. Make the validity rule depend on the observation type (positive for SWC / ET-resistivity, any finite value for pressure heads) via a small dict `{data_type: rule}`, and unit-test it.
3. **DONE (see Case 4)** , **A single observation**: `np.atleast_1d` in `_get_data2assimilate` so one sensor works; case 4 (one SWC sensor).
4. **DONE (`DAConfig.save_results`)** , **Persist `df_DA`**: it exists only in memory (a crash loses everything). Write it (and `ET_DA_xr`) next to the performance parquet at every cycle in `_save_step_outputs`; this also makes the regression baseline possible without a Python session.
5. **DONE (commit pinned in `pyCATHY/cathy_tools.py`; fingerprint removed)** , **Pin the CATHY sources**: `DA(...)` clones the HEAD of `github.com/CATHY-Org/CATHY_src_org` on first use, so two runs on different days may not use the same Fortran. Record the commit hash in the project (and in the baseline folder) and allow pinning.
6. **DONE (`DAConfig.seed`, global generator only: the filters in `enkf.py` use `np.random`)** , **Reproducible randomness**: the filters use the global `np.random` state. Accept a `seed` / `np.random.Generator` in `DAConfig` and pass it down (the baseline scripts currently rely on `np.random.seed`).
7. **DONE (see log)** Logging (section 5.9): replace the mixed `print` / `console.print` by `logging` plus the rich handler, with a `verbose` level; the `DAConfig.verbose` flag already exists.
8. **Continuous integration**: the sandbox showed that `apt-get install gfortran` + a clone + `pip install` is enough to run CATHY, so a GitHub Actions job can run `black --check`, `ruff`, `test_performance_pq.py`, `test_run_analysis.py` and both baseline cases (about 5 minutes) on every push.
9. **DONE (see log)** Type hints on the new public pieces (`DAConfig`, `AnalysisConfig`, `AnalysisResult`, `run_analysis`) and a `pyproject.toml` section with the ruff/black settings used here (`select = F401,F841,F821,F811,B006`).
10. **DONE** , **`DAConfig.analysis`**: store the `AnalysisConfig` inside the `DAConfig` (today `_DA_analysis` builds it from `DAConfig.inflation` and the per-cycle localisation matrix) so users can choose Sakov, inflation of parameters, jitter and the particle-filter settings from one object.
