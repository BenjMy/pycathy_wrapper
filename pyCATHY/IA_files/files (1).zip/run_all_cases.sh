#!/bin/bash
# Regression baseline: runs the real DA cases of baseline_case_run.py on the cathy_DA.py found in
# $CATHY_DA_DIR (default: the installed pyCATHY.DA.cathy_DA) and compares each result with its
# reference in $REFS (df_DA, df_performance, dict_parm_pert, ET_DA_xr).
#
#   CAPTURE=1 ./run_all_cases.sh    # once, with the file you trust: writes the references
#   ./run_all_cases.sh              # after every change: compares with the references
#
# Cases run ONE AT A TIME (a run needs ~2-3 GB; two at once get killed, exit 137). Set NO_COV_PLOT=1
# on machines with less than ~4 GB (skips only the covariance figure; the numbers do not change).
# Case 14 (PARM_CASE=atmbc) is not listed: it fails in the original code too (see
# "Checks to do" in REFACTORING_README.md).
export USE_CONFIG=1
[ -n "$CATHY_DA_DIR" ] && export CATHY_DA_DIR
REFS=${REFS:-./baseline_refs}
run() { name=$1; ref=$2; shift 2
  if [ -n "$CAPTURE" ]; then target="CAPTURE_TO=$REFS/$ref"; else target="COMPARE_WITH=$REFS/$ref"; fi
  echo "=== $name"
  env "$@" WORK=./work_baseline_$name $target python baseline_case_run.py 2>&1 \
    | grep -E "^baseline (comparison|captured)|Traceback|Error|^  - " | head -8
  rm -rf ./work_baseline_$name   # ~115 MB per run
}
run case01_states      ref_states        X=1
run case02_ks          ref_ks            UPDATE_KS=1
run case03_locnodes    ref_locnodes      LOCALISATION=nodes
run case04_single      ref_single        N_SENSORS=1
run case05_tensio      ref_tensio        OBS_TYPE=tensio
run case06_et          ref_et            OBS_TYPE=ETact
run case07_poros       ref_poros         UPDATE_POROS=1
run case08_seed_save   ref_states        SEED_IN_CONFIG=1 SAVE_RESULTS=1
run case09_no_obs_step ref_noobs         EXTRA_ATMBC=1
run case10_serial      ref_states        SERIAL=1
run case11_vg          ref_vg            PARM_CASE=vg
run case12_feddes      ref_feddes        PARM_CASE=feddes
run case13_wtpos       ref_wtpos         PARM_CASE=wtpos
run case15_log_obs     ref_logobs        LOG_OBS=1
run case16_loc_single  ref_loc_single    LOCALISATION=nodes N_SENSORS=1
echo ALL_DONE
