"""Tests for `run_analysis` against the real pyCATHY DA code (README step 3.1).

Run with pytest (``pytest pyCATHY/tests/test_DA_run_analysis.py``) or as a script.
pyCATHY on PyPI is outdated: use the GitHub sources, e.g.
    git clone --depth 1 https://github.com/BenjMy/pycathy_wrapper /tmp/pcgh
    PYTHONPATH=/tmp/pcgh python test_run_analysis.py
(a loose ``cathy_DA.py`` next to this script is also accepted; needs numpy, pandas,
xarray, rich, shapely, ... i.e. whatever `import cathy_DA` needs).
"""

import contextlib
import io
import sys
import warnings

import numpy as np

warnings.simplefilter("ignore")
try:  # installed / repository layout
    from pyCATHY.DA import cathy_DA as C
except ImportError:
    try:  # loose file next to this script (see the docstring)
        import cathy_DA as C
    except ImportError as exc:  # pyCATHY (GitHub version) not available
        print(f"SKIPPED: cannot import cathy_DA ({exc})")
        if "pytest" in sys.modules:
            import pytest

            pytest.skip("cathy_DA not importable", allow_module_level=True)
        sys.exit(0)

import logging

C.logger.setLevel(logging.CRITICAL)  # keep the test output quiet

N_STATE, N_OBS, N_ENS = 20, 3, 10
rng = np.random.default_rng(0)
X = rng.normal(-1, 0.3, (N_STATE, N_ENS))
H = np.zeros((N_OBS, N_STATE))
H[0, 2] = H[1, 7] = H[2, 15] = 1
PRED = H @ X
DATA = PRED.mean(1) + 0.1
COV = np.eye(N_OBS) * 0.05
PARAM_NONE = np.zeros((0, N_ENS))  # state-only update, as built by `_DA_analysis`
PARAM_ONE = rng.normal(0, 1, (1, N_ENS))


def run(da_type, param=PARAM_NONE, **kwargs):
    kwargs.setdefault("alpha", 1.0)
    kwargs.setdefault("localisationMatrix", [])
    with contextlib.redirect_stdout(io.StringIO()):
        return C.run_analysis(
            da_type, DATA, COV, param, ["St. var."], [X, X], PRED, **kwargs
        )


def test_run_analysis():
    # every filter returns an AnalysisResult with the same orientations:
    # analysis (n_state, n_members) and analysis_param (n_members, n_param)
    L = np.ones((N_STATE, N_OBS))
    cases = {
        "enkf_Evensen2009": {},
        "enkf_Evensen2009_Sakov": {},
        "enkf_analysis_inflation": {},
        "enkf_analysis_inflation_multiparm": {},
        "enkf_dual_analysis": {},
        "enkf_dual_analysis_Sakov": {},
        "enkf_analysis_localized_with_inflation": {"localisationMatrix": L},
    }
    for da_type, kwargs in cases.items():
        for param in (PARAM_NONE, PARAM_ONE):
            res = run(da_type, param, **kwargs)
            assert isinstance(res, C.AnalysisResult), da_type
            assert res.analysis.shape == (N_STATE, N_ENS), (da_type, res.analysis.shape)
            assert res.analysis_param.shape == (N_ENS, param.shape[0]), (
                da_type,
                param.shape,
                res.analysis_param.shape,
            )
            assert set(res.diagnostics) == set(C._ENKF_DIAGNOSTICS), da_type

    # particle filter needs parameters; no EnKF diagnostics, filter outputs in `extra`
    res = run("pf", PARAM_ONE)
    assert res.analysis.shape == (N_STATE, N_ENS)
    assert res.analysis_param.shape == (N_ENS, 1)
    assert res.diagnostics is None
    assert {"weights", "n_eff", "resampled", "observation"} <= set(res.extra)

    # deterministic for identical inputs (analysis uses the global numpy seed)
    np.random.seed(0)
    a = run("enkf_Evensen2009").analysis
    np.random.seed(0)
    assert np.allclose(a, run("enkf_Evensen2009").analysis)

    # the state to update is selected with `default_state`
    with contextlib.redirect_stdout(io.StringIO()):
        res_sw = C.run_analysis(
            "enkf_Evensen2009",
            DATA,
            COV,
            PARAM_NONE,
            ["St. var."],
            [X, 0.3 * X],
            PRED,
            default_state="sw",
        )
    assert res_sw.analysis.shape == (N_STATE, N_ENS)

    # unknown / removed DA types fail loudly (used to return None silently)
    for bad in ["nope", "enkf_analysis_localized"]:
        try:
            run(bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"{bad!r} should raise ValueError")

    # key of the perturbation ensemble of a DA cycle (was duplicated in 3 places)
    assert C._update_key(0) == "ini_perturbation"
    assert C._update_key(3) == "update_nb3"

    # `_restores_cwd`: directory changes never leak out of the decorated method
    import os

    @C._restores_cwd
    def moves(target, fail=False):
        os.chdir(target)
        if fail:
            raise RuntimeError("boom")
        return "done"

    start = os.getcwd()
    assert moves("/tmp") == "done" and os.getcwd() == start
    try:
        moves("/tmp", fail=True)
    except RuntimeError:
        pass
    assert os.getcwd() == start

    # --- prediction validation (extracted from run_DA_sequential) --------------
    from types import SimpleNamespace

    check = C.DA._validate_prediction
    check(SimpleNamespace(isET=False), np.array([0.1, 0.2]))
    check(SimpleNamespace(isET=True), np.array([0.0, 0.2]))  # zero ET is valid
    for isET, bad in [
        (False, [0.1, 0.0]),
        (False, [0.1, -1.0]),
        (False, [np.nan, 1.0]),
        (True, [-0.1, 1.0]),
    ]:
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                check(SimpleNamespace(isET=isET), np.array(bad))
        except ValueError:
            pass
        else:
            raise AssertionError(f"{bad} (isET={isET}) must be rejected")

    # observation types: tensiometers (pressure heads) may be negative, others may not
    def stub(types, isET=False):
        return SimpleNamespace(
            isET=isET,
            _obs_key_select=lambda lst: (
                [f"s{i}" for i in range(len(types))],
                [{"data_type": t} for t in types],
            ),
        )

    neg = np.array([[-1.0, -2.0], [-0.5, -0.7]])  # 2 observations x 2 members
    check(stub(["tensio", "tensio"]), neg, ["all"])  # accepted
    mixed = np.array([[-1.0, -2.0], [0.3, 0.4]])  # tensio negative, swc positive
    check(stub(["tensio", "swc"]), mixed, ["all"])  # accepted row by row
    for types, bad in [
        (["swc", "swc"], neg),
        (["tensio", "swc"], np.array([[-1.0, -2.0], [-0.3, 0.4]])),
    ]:
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                check(stub(types), bad, ["all"])
        except ValueError:
            pass
        else:
            raise AssertionError(f"{types} with {bad.tolist()} must be rejected")
    try:  # NaN is invalid even for tensiometers
        with contextlib.redirect_stdout(io.StringIO()):
            check(stub(["tensio"]), np.array([[np.nan, -1.0]]), ["all"])
    except ValueError:
        pass
    else:
        raise AssertionError("NaN must be rejected")

    # observation mask of one zone (extracted from the localisation loop)
    surf = np.array([True, False, True, False])  # 4 surface nodes, zone = nodes 0 and 2
    # maps: one value per surface node -> the surface mask is used as is
    assert (C.build_obs_node_mask(surf, np.arange(4), np.array([0, 2])) == surf).all()
    # EM: 2 coils -> the surface mask is repeated
    em = C.build_obs_node_mask(surf, np.arange(8) % 4, np.array([0, 2]), n_repeat=2)
    assert (em == np.tile(surf, 2)).all()
    # point sensors: valid if the mesh node is one of the zone nodes (all depths)
    pts = C.build_obs_node_mask(surf, np.array([5692, 5000]), np.array([5692, 6000]))
    assert pts.tolist() == [True, False]

    # post-analysis check: members with a non-physical updated porosity are rejected
    class _Console:
        def print(self, *a, **k):
            pass

    stub_poro = SimpleNamespace(
        console=_Console(),
        NENS=4,
        dict_parm_pert={"porosity0": {"update_nb1": np.array([0.5, 1.2, -0.1, 0.9])}},
    )
    valid = C.DA._check_after_analysis(
        stub_poro, "update_nb1", ["St. var.", "porosity0"]
    )
    assert sorted(valid) == [0, 3], valid

    # --- DAConfig ---------------------------------------------------------------
    import warnings as _w

    kw = {"IPRT1": 2, "verbose": True}
    cfg = C.DAConfig.from_legacy_kwargs(kw)  # nothing DA-specific: no warning, defaults
    assert cfg == C.DAConfig(verbose=True) and kw == {"IPRT1": 2, "verbose": True}

    kw = {"IPRT1": 2, "inflation": 1.2, "threshold_rejected": 5, "cleanup_vtk": "all"}
    with _w.catch_warnings(record=True) as caught:
        _w.simplefilter("always")
        cfg = C.DAConfig.from_legacy_kwargs(kw)
    assert any(issubclass(c.category, DeprecationWarning) for c in caught)
    assert kw == {"IPRT1": 2}  # DA keys popped, processor keys left alone
    assert (cfg.inflation, cfg.threshold_rejected, cfg.cleanup_vtk) == (1.2, 5, "all")

    # localisation: a single-entry list is converted to the string the mask builder compares to
    assert C.DAConfig(localisation=["nodes"]).localisation == "nodes"
    assert C.DAConfig(localisation=[]).localisation is None
    assert C.DAConfig(localisation="zones").localisation == "zones"
    for bad_loc in (["nodes", "zones"], "everywhere"):
        try:
            C.DAConfig(localisation=bad_loc)
        except ValueError:
            pass
        else:
            raise AssertionError(f"localisation={bad_loc!r} must be rejected")

    assert C.DAConfig().seed is None and C.DAConfig().save_results is False
    kw = {"seed": 3, "save_results": True, "IPRT1": 2}
    with _w.catch_warnings():
        _w.simplefilter("ignore")
        cfg = C.DAConfig.from_legacy_kwargs(kw)
    assert (cfg.seed, cfg.save_results) == (3, True) and kw == {"IPRT1": 2}
    assert C.DAConfig().backup_fort777 is False
    assert (
        C.DAConfig.from_legacy_kwargs({"backup_fort777": True}).backup_fort777 is True
    )

    try:
        C.DAConfig(cleanup_vtk="everything")
    except ValueError:
        pass
    else:
        raise AssertionError("invalid cleanup_vtk must fail at construction")

    # --- AnalysisConfig -------------------------------------------------------
    # legacy kwargs and config give identical results
    np.random.seed(3)
    legacy = run("enkf_analysis_inflation", PARAM_ONE, alpha=1.3)
    np.random.seed(3)
    with contextlib.redirect_stdout(io.StringIO()):
        new = C.run_analysis(
            "enkf_analysis_inflation",
            DATA,
            COV,
            PARAM_ONE,
            ["St. var."],
            [X, X],
            PRED,
            config=C.AnalysisConfig(inflation_states=1.3),
        )
    assert np.allclose(legacy.analysis, new.analysis)
    assert np.allclose(legacy.analysis_param, new.analysis_param)

    # `inflation` and `alpha` are two names of the same option
    cfg_a = C.AnalysisConfig.from_legacy_kwargs({"alpha": 1.2})
    cfg_i = C.AnalysisConfig.from_legacy_kwargs({"inflation": 1.2})
    assert cfg_a == cfg_i and cfg_a.inflation_states == 1.2

    # an empty localisation matrix (list or array) means "no localisation"
    assert C.AnalysisConfig(localisation_matrix=[]).localisation_matrix is None
    assert (
        C.AnalysisConfig(localisation_matrix=np.zeros((0, 0))).localisation_matrix
        is None
    )

    # localized filter without a localisation matrix runs (no localisation)
    res = run(
        "enkf_analysis_localized_with_inflation", PARAM_ONE, localisationMatrix=[]
    )
    assert res.analysis.shape == (N_STATE, N_ENS)

    # the inflation of the config is applied by the localized filter too
    np.random.seed(4)
    plain = run(
        "enkf_analysis_localized_with_inflation", PARAM_ONE, localisationMatrix=L
    )
    np.random.seed(4)
    inflated = run(
        "enkf_analysis_localized_with_inflation",
        PARAM_ONE,
        localisationMatrix=L,
        alpha=2.0,
    )
    spread = lambda a: np.std(a, axis=1).mean()
    assert spread(inflated.analysis) > spread(plain.analysis)

    # unknown options and legacy options mixed with `config` are rejected
    for kwargs in ({"unknown_option": 1}, {"alpha": 1.1, "config": C.AnalysisConfig()}):
        try:
            run("enkf_Evensen2009", **kwargs)
        except TypeError:
            pass
        else:
            raise AssertionError(f"{kwargs} should raise TypeError")

    # state-only update with an empty *list* breaks the inflation filters: callers
    # must pass an empty (0, n_members) array (see `_DA_analysis`)
    try:
        run("enkf_analysis_inflation", param=[])
        raise AssertionError("empty list unexpectedly accepted")
    except ValueError:
        pass

    # `_working_directory`: the directory is restored after the block, also on error
    start = os.getcwd()
    with C._working_directory("/tmp"):
        assert os.getcwd() == os.path.realpath("/tmp")
    assert os.getcwd() == start
    try:
        with C._working_directory("/tmp"):
            raise RuntimeError("boom")
    except RuntimeError:
        pass
    assert os.getcwd() == start

    # --- `_check_before_analysis`: which members are rejected, and why ----------------
    import pandas as pd

    printed = []

    class _Rec:
        def print(self, text, *a, **k):
            printed.append(text)

    runs = {  # member index (0-based) -> content of its `mbeconv`
        0: pd.DataFrame({"TIME": [1800.0, 3600.0], "CUM.": [1.0, 2.0]}),  # fine
        1: pd.DataFrame({"TIME": [1800.0, 3600.0], "CUM.": [1.0, np.nan]}),  # NaN
        2: pd.DataFrame({"TIME": [500.0, 1000.0], "CUM.": [1.0, 2.0]}),  # stops early
        3: pd.DataFrame({"TIME": [], "CUM.": []}),  # empty
        4: IndexError("single positional indexer is out-of-bounds"),  # unreadable
    }

    def fake_read_mbeconv(path):
        run = runs[int(path.split("cathy_")[1].split(os.sep)[0]) - 1]
        if isinstance(run, Exception):
            raise run
        return run

    stub_check = SimpleNamespace(
        NENS=6,
        workdir="w",
        project_name="p",
        console=_Rec(),
        parm={"(TIMPRT(I),I=1,NPRT)": [0, 3600], "DELTAT": 1.0},
        dict_parm_pert={},
    )
    for name in ("_member_rejection_reason", "_raise_if_too_many_rejected"):
        setattr(stub_check, name, getattr(C.DA, name).__get__(stub_check))
    original_read = C.out_CT.read_mbeconv
    C.out_CT.read_mbeconv = fake_read_mbeconv
    try:
        # member 5 is not in `ens_valid`: rejected without being read
        rejected = C.DA._check_before_analysis(
            stub_check, ens_valid=[0, 1, 2, 3, 4], threshold_rejected=100
        )
        assert rejected == [False, True, True, True, True, True], rejected
        text = " ".join(printed)
        assert "CUM." in text and "df_mbeconv['time']1000.0" in text, printed
        assert (
            "len(df_mbeconv)['TIME']0" in text
        ), printed  # empty file: reported as such
        # too many rejected members stop the run
        try:
            C.DA._check_before_analysis(
                stub_check, ens_valid=[0, 1, 2, 3, 4], threshold_rejected=50
            )
        except ValueError as exc:
            assert "100" not in str(exc) and "83" in str(exc), exc
        else:
            raise AssertionError("83% rejected must stop the run")
    finally:
        C.out_CT.read_mbeconv = original_read

    # --- `_check_after_analysis`: physical bounds of the updated parameters -----------
    def post_check(parms, n=4, depth=2.0, names=None):
        stub = SimpleNamespace(
            console=_Console(),
            NENS=n,
            dict_parm_pert={k: {"u": np.array(v, float)} for k, v in parms.items()},
            grid3d={"mesh3d_nodes": np.array([[0, 0, 0.0], [0, 0, -depth]])},
        )
        stub._max_root_depth = C.DA._max_root_depth.__get__(stub)
        return sorted(
            C.DA._check_after_analysis(stub, "u", names or ["St. var."] + list(parms))
        )

    assert post_check({"Ks0": [1, -1, 0, 2]}) == [
        0,
        2,
        3,
    ]  # negative Ks; 0 is on the bound
    assert post_check({"PCREF0": [-1, 0.5, -2, 0]}) == [
        0,
        2,
        3,
    ]  # PCREF must not be positive
    assert post_check({"rFluid_Archie": [10, -1, 5, 2]}) == [0, 2, 3]
    assert post_check({"a_Archie": [1, 4, -1, 3]}) == [0, 3]  # in [0, 3]
    assert post_check({"ZROOT0": [0.5, 2.5, 2.0, 1.0]}) == [
        0,
        2,
        3,
    ]  # deeper than the mesh
    assert post_check({"n_VG0": [-5, 9, 0, 1]}) == [0, 1, 2, 3]  # no bound known
    # NaN is not flagged; a member invalid for one parameter is out for good
    assert post_check(
        {"Ks0": [1, np.nan, 1, 1], "porosity0": [0.4, 0.4, 1.3, 0.4]}
    ) == [
        0,
        1,
        3,
    ]
    # the root depth is only needed (and the mesh only read) for a root depth
    nodepth = SimpleNamespace(
        console=_Console(),
        NENS=2,
        dict_parm_pert={"Ks0": {"u": np.array([1.0, 2.0])}},
    )
    assert sorted(C.DA._check_after_analysis(nodepth, "u", ["Ks0"])) == [0, 1]

    # --- explicit state: `DA.__init__` defaults the DA-owned attributes ---------------
    original_init = C.CATHY.__init__

    def fake_cathy_init(
        self, *args, **kwargs
    ):  # what CATHY.__init__ sets that matters here
        self.count_DA_cycle = None
        self.init_args = (args, kwargs)

    C.CATHY.__init__ = fake_cathy_init
    try:
        simu = C.DA("workdir", prj_name="p", notebook=False)
    finally:
        C.CATHY.__init__ = original_init
    assert simu.init_args == (("workdir",), {"prj_name": "p", "notebook": False})
    assert simu.Archie_parms is None and simu.VGN_parms is None
    assert simu.localisationMatrix is None and simu.ens_valid is None
    assert simu.isET is False and simu.ET_DA_xr is None and simu.df_DA.empty
    assert simu.Archie_parms_mat_ens == [] and simu.count_atmbc_cycle == 0
    # CATHY decides "a DA is running" with `count_DA_cycle is not None`: not defaulted by the DA
    assert simu.count_DA_cycle is None

    # --- `map_states2Observations`: dispatch by observation type ---------------------
    import pandas as pd

    class _Ui(_Console):
        def rule(self, *a, **k):
            pass

    def make_mapper_stub(types, ens_valid=(0, 1)):
        obs = {
            "tensio0": {"data_type": "tensio", "mesh_nodes": np.array([1, 2])},
            "swc0": {"data_type": "swc", "mesh_nodes": np.array([3])},
            "ETact0": {"data_type": "ETact", "mesh_nodes": np.array([0])},
            "EM0": {"data_type": "EM", "mesh_nodes": np.array([0])},
            "ERT0": {"data_type": "ERT", "mesh_nodes": np.array([0])},
            "ERT1": {"data_type": "ERT", "mesh_nodes": np.array([0])},
        }
        stub = SimpleNamespace(
            ens_valid=list(ens_valid),
            NENS=2,
            workdir="w",
            project_name="p",
            input_dirname="input",
            output_dirname="output",
            dem_parameters=None,
            cathyH={"MAXVEG": 1},
            grid3d={"mesh3d_nodes": None},
            console=_Ui(),
            dict_obs={0.0: {k: obs[k] for k in types}},
            count_DA_cycle=0,
            Archie_parms={
                "porosity": 0.4,
                "rFluid_Archie": [1],
                "pert_sigma_Archie": [0],
            },
            df_Archie="archie0",
            isET=False,
            map_prop_2mesh_markers=lambda name, values, to_nodes: (
                None,
                np.array([0.3]),
            ),
            _predict_ET=lambda path, obs2map: np.array([9.0]),
        )

        def read_outputs(filename, path):
            n = int(path.split("cathy_")[1].split(os.sep)[0])  # member number (1-based)
            if filename == "psi":
                return pd.DataFrame([np.full(10, float(n))])
            return pd.DataFrame([np.full(10, 0.1 * n)]), None

        stub.read_outputs = read_outputs
        for name in (
            "_obs_key_select",
            "_check_prediction_shape",
            "_predict_member",
            "_ert_ensemble_inputs",
            "_map_ERT",
        ):
            setattr(stub, name, getattr(C.DA, name).__get__(stub))
        return stub

    saved = (C.in_CT.read_soil, C.mapper.tensio_mapper, C.mapper.swc_mapper)
    saved_em = C.mapper._map_EM
    saved_ert = (C.mapper._map_ERT_parallel, C.mapper._add_2_ensemble_Archie)
    C.in_CT.read_soil = lambda *a, **k: (pd.DataFrame({"POROS": [0.4]}), None)
    C.mapper.tensio_mapper = lambda state, nodes: np.asarray(state[0])[nodes]
    C.mapper.swc_mapper = lambda state, nodes, *a: np.asarray(state[1])[nodes]
    em_calls = []

    def fake_em(*args, **kwargs):
        em_calls.append(args)
        return np.array([5.0, 6.0]), "df_archie_em"

    C.mapper._map_EM = fake_em
    ert_calls = []

    def fake_ert(*args, **kwargs):
        ert_calls.append((args, kwargs))
        return np.array([[7.0, 7.5]]), "df_archie_ert", None

    C.mapper._map_ERT_parallel = fake_ert
    C.mapper._add_2_ensemble_Archie = lambda old, new: old + "+" + new
    try:
        # tensiometers (2 nodes) then swc (1 node): rows = observations, columns = members
        st = make_mapper_stub(["tensio0", "swc0"])
        Hx = C.DA.map_states2Observations(st)
        assert st.isET is False
        assert np.allclose(Hx, [[1, 2], [1, 2], [0.1, 0.2]]), Hx

        # ET is predicted first, from `_predict_ET`
        st = make_mapper_stub(["ETact0", "tensio0"])
        Hx = C.DA.map_states2Observations(st)
        assert st.isET is True and np.allclose(Hx, [[9, 9], [1, 2], [1, 2]]), Hx

        # EM gets the case, the member path and its porosity
        st = make_mapper_stub(["EM0"])
        Hx = C.DA.map_states2Observations(st)
        assert np.allclose(Hx, [[5, 5], [6, 6]]) and len(em_calls) == 2
        assert em_calls[1][4].endswith("cathy_2") and em_calls[1][5] == 1

        # ERT: the whole ensemble at once, appended below the other observations;
        # works when ERT is not the last observation
        for types in (["swc0", "ERT0"], ["ERT0", "swc0"]):
            st = make_mapper_stub(types)
            Hx = C.DA.map_states2Observations(st, parallel=True)
            assert np.allclose(Hx, [[0.1, 0.2], [7.0, 7.5]]), Hx
            assert st.df_Archie == "archie0+df_archie_ert"
        # one forward model per cycle (not one per ERT key) ...
        ert_calls.clear()
        C.DA.map_states2Observations(make_mapper_stub(["swc0", "ERT0"]), parallel=True)
        assert len(ert_calls) == 1
        # ... and two ERT surveys at the same time are refused (the mapper handles one)
        try:
            C.DA.map_states2Observations(
                make_mapper_stub(["ERT0", "ERT1"]), parallel=True
            )
        except ValueError as exc:
            assert "only one ERT survey" in str(exc)
        else:
            raise AssertionError("two ERT keys must raise")
        assert len(ert_calls) == 1  # the forward model was not run again
        args, _ = ert_calls[0]
        assert [p.split("cathy_")[1] for p in args[5]] == ["1", "2"]  # member paths
        # without parallel=True ERT cannot be mapped: say so instead of failing later
        try:
            C.DA.map_states2Observations(make_mapper_stub(["ERT0"]), parallel=False)
        except NotImplementedError:
            pass
        else:
            raise AssertionError("ERT without parallel=True must raise")
    finally:
        C.in_CT.read_soil, C.mapper.tensio_mapper, C.mapper.swc_mapper = saved
        C.mapper._map_EM = saved_em
        C.mapper._map_ERT_parallel, C.mapper._add_2_ensemble_Archie = saved_ert

    # --- pieces of `_DA_analysis` ---------------------------------------------------------
    stub_cov = SimpleNamespace(stacked_data_cov=[np.eye(3)], count_DA_cycle=0)
    assert C.DA._data_cov_of_cycle(stub_cov, 3).shape == (3, 3)
    try:
        C.DA._data_cov_of_cycle(stub_cov, 2)
    except ValueError as exc:
        assert "Wrong stacked_data_cov shape" in str(exc)
    else:
        raise AssertionError("a covariance of the wrong size must be rejected")

    loc_cycle = np.ones((4, 3))
    stub_cfg = SimpleNamespace(
        inflation=1.2,
        localisationMatrix=None,
        count_DA_cycle=0,
        config=SimpleNamespace(analysis=None),
    )
    cfg = C.DA._analysis_config_of_cycle(
        stub_cfg
    )  # default config built from the inflation
    assert cfg.inflation_states == 1.2 and cfg.localisation_matrix is None
    stub_cfg.localisationMatrix = [loc_cycle]  # legacy matrix of the cycle
    assert C.DA._analysis_config_of_cycle(stub_cfg).localisation_matrix is not None
    own = C.AnalysisConfig(sakov=False, localisation_matrix=np.ones((2, 2)))
    stub_cfg.config = SimpleNamespace(analysis=own)
    stub_cfg.localisationMatrix = None  # the user's own config is kept ...
    cfg = C.DA._analysis_config_of_cycle(stub_cfg)
    assert cfg.sakov is False and cfg.localisation_matrix.shape == (2, 2)
    stub_cfg.localisationMatrix = [loc_cycle]  # ... except for the matrix of the cycle
    cfg = C.DA._analysis_config_of_cycle(stub_cfg)
    assert cfg.sakov is False and cfg.localisation_matrix.shape == (4, 3)

    # --- `_analyse`: global or zone by zone ---------------------------------------------
    zp = C.DA._zone_parameters
    assert zp(SimpleNamespace(localisation="zones"), ["St. var.", "Ks0", "Ks1"], 1) == [
        "St. var.",
        "Ks1",
    ]
    assert zp(SimpleNamespace(localisation="veg_map"), ["St. var."], 0) == ["St. var."]
    assert zp(SimpleNamespace(localisation="nodes"), ["St. var.", "Ks0"], 1) == [
        "St. var.",
        "Ks0",
    ]

    def zones_stub(observed_nodes, localisation_mode="nodes"):
        prior = np.full((4, 3), -9.0)
        stub = SimpleNamespace(
            localisation=localisation_mode,
            localisationBool=False,
            console=_Console(),
            zone=np.zeros(4),
            veg_map=None,
            hapin=None,
            DEM=None,
            grid3d={"nnod": 4, "nnod3": 8},
            ens_valid=[0, 1, 2],
            get_mesh_mask_nodes_observed=lambda obs: (
                [np.array(observed_nodes)],
                np.zeros((1, 4)),
            ),
            _read_state_ensemble=lambda: (prior.copy(), None, 3, 4),
            _get_data2assimilate=lambda obs: (np.array([1.0, 2.0, 3.0]), ["a", "b"]),
        )
        calls = []

        def fake_da_analysis(prediction, da_type, parms, obs, **kw):
            nodes = kw["obs_mesh_nodes_valid"]  # node indices of the zone
            calls.append((parms, kw["obs_valid"].tolist()))
            analysis = np.full((len(nodes), 3), float(len(calls)))
            return prior, prior, np.array([1.0]), analysis, np.zeros((3, 1))

        stub._DA_analysis = fake_da_analysis
        stub.calls = calls
        for name in (
            "_analyse_by_zones",
            "_analyse_global",
            "_zone_parameters",
            "_assemble_localised_analysis",
        ):
            setattr(stub, name, getattr(C.DA, name).__get__(stub))
        return stub

    real_mask = C.localisation.create_mask_localisation
    # 4 surface nodes in 2 zones: nodes 0-1 (zone 0) and 2-3 (zone 1)
    C.localisation.create_mask_localisation = lambda *a: (
        [np.array([0, 1]), np.array([2, 3])],  # node indices of each zone
        np.array([[0, 0, 1, 1]]),
    )
    try:
        # sensors in both zones: both analysed, assembled in node order on the whole mesh
        st = zones_stub([0, 2])
        out = C.DA._analyse(st, np.zeros((2, 3)), "enkf", ["St. var."], "all")
        assert st.localisationBool is True and len(st.calls) == 2
        assert np.allclose(out[3][:, 0], [1, 1, 2, 2]), out[3]  # zone 0 then zone 1
        # the data returned are ALL the observations of the cycle (not those of one zone):
        # the performance compares them with the predictions of all the observations
        assert np.allclose(out[2], [1.0, 2.0, 3.0]), out[2]
        # a sensor in zone 0 only: the other nodes keep the prior state
        st = zones_stub([0])
        out = C.DA._analyse(st, np.zeros((1, 3)), "enkf", ["St. var."], "all")
        assert len(st.calls) == 1
        assert np.allclose(out[3][:, 0], [1, 1, -9, -9]), out[3]
        # no sensor in any zone: a clear error
        try:
            C.DA._analyse(
                zones_stub([99]), np.zeros((1, 3)), "enkf", ["St. var."], "all"
            )
        except ValueError as exc:
            assert "no observation lies in any" in str(exc)
        else:
            raise AssertionError("no observation in any zone must raise")
        # without localisation: the global analysis
        st = zones_stub([0], localisation_mode=None)
        out = C.DA._analyse(st, np.zeros((1, 3)), "enkf", ["St. var."], "all")
        assert st.localisationBool is False and len(st.calls) == 1
        assert st.calls[0][1] == [True]  # every observation is valid
    finally:
        C.localisation.create_mask_localisation = real_mask

    # --- soil parameters of one member: `_assign_soil_value` and the "write when complete" rule
    def soil_table():
        idx = pd.MultiIndex.from_product([[1, 2], [1, 2, 3]], names=["zone", "layer"])
        return pd.DataFrame({"PERMX": 1.0, "POROS": 0.4}, index=idx)

    df = soil_table()  # zone: index + 1 is the zone number
    C._assign_soil_value(df, "zone", 0, ["PERMX"], 9.0)
    assert (df.loc[1, "PERMX"] == 9.0).all() and (df.loc[2, "PERMX"] == 1.0).all()
    df = soil_table()  # layers: index is the layer number
    C._assign_soil_value(df, "layers", 2, ["POROS"], 0.1)
    assert (df.xs(2, level="layer")["POROS"] == 0.1).all() and (
        df["POROS"] == 0.1
    ).sum() == 2
    df = soil_table()  # root_map: the zones of vegetation index + 1
    C._assign_soil_value(
        df,
        "root_map",
        1,
        ["PERMX"],
        5.0,
        veg_map=np.array([1, 2, 2]),
        zone=np.array([1, 1, 2]),
    )
    assert (df.loc[1, "PERMX"] == 5.0).all() and (df.loc[2, "PERMX"] == 5.0).all()
    df = soil_table()  # anything else: every row
    C._assign_soil_value(df, None, None, ["PERMX", "POROS"], 3.0)
    assert (df.to_numpy() == 3.0).all()

    written = []
    stub_soil = SimpleNamespace(
        NENS=2,
        workdir="w",
        project_name="p",
        dem_parameters=None,
        cathyH={"MAXVEG": 1},
        verbose=False,
        veg_map=None,
        zone=None,
        soil_FP={"FP_map": "fp"},
        update_soil=lambda **kw: written.append(kw["SPP_map"].copy()),
    )
    for name in ("_soil_tables_to_fill", "_write_member_soil"):
        setattr(stub_soil, name, getattr(C.DA, name).__get__(stub_soil))
    real_read_soil = C.in_CT.read_soil
    C.in_CT.read_soil = lambda *a, **k: (soil_table(), None)
    pert = {
        "Ks0": {"pert_control_name": "zone", "u": np.array([10.0, 20.0])},
        "Ks1": {"pert_control_name": "zone", "u": np.array([11.0, 21.0])},
    }
    try:
        tables = []
        upd = C.DA._update_soil_params_from_perturbations
        tables = upd(stub_soil, pert, tables, ["Ks", "0"], "Ks0", "u", 1, False)
        assert len(tables) == 2 and written == []  # zone 2 still empty: nothing written
        assert tables[1]["PERMX"].isna().sum() == 3 and tables[0]["PERMX"].isna().all()
        tables = upd(stub_soil, pert, tables, ["Ks", "1"], "Ks1", "u", 1, False)
        assert len(written) == 1  # member 2 complete: its soil file is written, once
        assert (written[0].loc[1, "PERMX"] == 20.0).all() and (
            written[0].loc[2, "PERMX"] == 21.0
        ).all()
        w = written[0]  # Ks sets the three permeability columns
        assert (w["PERMY"] == w["PERMX"]).all() and (w["PERMZ"] == w["PERMX"]).all()
        try:
            upd(
                stub_soil,
                {"Foo0": {"pert_control_name": "zone", "u": [1, 2]}},
                [],
                ["Foo", "0"],
                "Foo0",
                "u",
                0,
                False,
            )
        except ValueError as exc:
            assert "Unknown parameter 'Foo'" in str(exc)
        else:
            raise AssertionError("an unknown soil parameter must raise")
    finally:
        C.in_CT.read_soil = real_read_soil

    # --- `_run_window`: one time window of the sequential DA -------------------------------
    log = []

    class _Rule(_Console):
        def rule(self, *a, **k):
            log.append("end-of-DA rule")

    stub_win = SimpleNamespace(
        NENS=3,
        ens_valid=[0, 1, 2],
        ENS_times=[1800.0],
        all_atmbc_times=[0.0, 1800.0, 3600.0, 5400.0],
        count_atmbc_cycle=0,
        console=_Rule(),
        _run_ensemble_hydrological_model=lambda parallel, exe: log.append(
            ("run", parallel, exe)
        ),
        _check_before_analysis=lambda ens_valid, thr: [False, True, False],
        _analysis_cycle=lambda *a: log.append(("analysis", a)) or ("state", "analysed"),
        _no_analysis_cycle=lambda: log.append("no analysis") or ("state0", "prior"),
        _log_end_of_time_step=lambda t: log.append(("end step", t)),
        _save_step_outputs=lambda **kw: log.append(
            ("save", kw["state_analysis"], kw["rejected_ens"])
        ),
        _update_input_ensemble=lambda parms, analysis=None: log.append(
            ("update inputs", analysis)
        ),
        _log_end_of_da_update=lambda: None,
    )
    opts = C._RunOptions("enkf", ["St. var."], "all", "update_nb1", True, "./cathy", 10)
    window = C.DA._run_window
    window(stub_win, 0.0, opts)  # no observation at t=0
    assert stub_win.ens_valid == [0, 2]  # the rejected member (1) is dropped
    assert [e if isinstance(e, str) else e[0] for e in log] == [
        "run",
        "no analysis",
        "end step",
        "save",
        "update inputs",
    ], log
    assert log[3] == ("save", "prior", [False, True, False])
    log.clear()
    window(
        stub_win, 1800.0, opts
    )  # observation: analysis, then the inputs get the analysis
    assert log[1] == ("analysis", ("enkf", ["St. var."], "all", "update_nb1", True))
    assert log[-1] == ("update inputs", "analysed") and stub_win.count_atmbc_cycle == 2
    log.clear()
    window(stub_win, 3600.0, opts)  # last window (TMAX follows): nothing to update
    assert stub_win.count_atmbc_cycle == 3
    assert "end-of-DA rule" in log and not any(
        e[0] == "update inputs" for e in log if isinstance(e, tuple)
    )

    # --- the performance never broadcasts one datum over all the predictions -------------
    assert C._compute_diff_matrix([1.0, 2.0], np.ones((2, 3))).shape == (2, 3)
    assert C._compute_diff_matrix(1.0, np.ones(3)).shape == (1, 3)  # one observation
    for n_data in (1, 3):  # 4 predictions: wrong number of observations
        try:
            C._compute_diff_matrix(np.zeros(n_data), np.ones((4, 2)))
        except ValueError as exc:
            assert "predictions" in str(exc)
        else:
            raise AssertionError(f"{n_data} observations vs 4 predictions must raise")

    # --- public import surface ------------------------------------------------------
    # other modules and the documentation do `from pyCATHY.DA.cathy_DA import <name>`
    for name in ("DA", "dictObs_2pd", "mapper", "localisation", "run_analysis"):
        assert hasattr(C, name), f"cathy_DA.{name} must stay importable"
    assert all(hasattr(C, name) for name in C.__all__)

    # --- logging ----------------------------------------------------------------
    # the invalid-prediction details are logged (as warnings) before the ValueError
    records = []

    class _Collect(logging.Handler):
        def emit(self, record):
            records.append(record)

    handler = _Collect()
    C.logger.addHandler(handler)
    C.logger.setLevel(logging.INFO)
    try:
        try:
            C.DA._validate_prediction(
                SimpleNamespace(isET=False), np.array([np.nan, 1.0])
            )
        except ValueError:
            pass
        assert any(
            r.levelno == logging.WARNING and "Invalid prediction" in r.getMessage()
            for r in records
        )
    finally:
        C.logger.removeHandler(handler)
        C.logger.setLevel(logging.CRITICAL)

    # `_configure_logging`: INFO by default, DEBUG when verbose; never touches the root logger
    root_handlers = list(logging.getLogger().handlers)
    C._configure_logging(False)
    assert C.logger.level == logging.INFO
    C._configure_logging(True)
    assert C.logger.level == logging.DEBUG
    assert logging.getLogger().handlers == root_handlers
    C.logger.setLevel(logging.CRITICAL)
    print("OK")


if __name__ == "__main__":
    test_run_analysis()
