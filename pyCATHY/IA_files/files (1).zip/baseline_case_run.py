"""Scratch script (NOT part of pyCATHY): tiny real DA case used as regression baseline."""
import os, sys, shutil, warnings, importlib
warnings.simplefilter("ignore")
import numpy as np

cathy_DA_dir = os.environ.get("CATHY_DA_DIR")          # directory containing the cathy_DA.py to test
if cathy_DA_dir:
    sys.path.insert(0, cathy_DA_dir)
    import cathy_DA as cdmod
    from cathy_DA import DA
else:
    import pyCATHY.DA.cathy_DA as cdmod
    from pyCATHY.DA.cathy_DA import DA
from pyCATHY.DA import perturbate
from pyCATHY.DA.observations import make_data_cov

if os.environ.get("NO_COV_PLOT"):                      # the covariance figure (7057 x 7057 matrices) needs several GB: skip it on small machines
    from pyCATHY.plotters import cathy_plots as _plt_CT
    _plt_CT.show_DA_process_ens = lambda *a, **k: None
DA_TYPE = os.environ.get("DA_TYPE", "enkf_Evensen2009")
WORK = os.environ.get("WORK", "./work_baseline_case")
shutil.rmtree(WORK, ignore_errors=True)
np.random.seed(0)

simu = DA(dirName=WORK, prj_name="tiny", notebook=False)
NENS = 4
simu.NENS = NENS
times = [0.0, 3600.0, 7200.0]
nodes = ([200, 300] if os.environ.get("OBS_TYPE") == "ETact" else [5692, 5000])[: int(os.environ.get("N_SENSORS", 2))]
dict_obs = {}
rng = np.random.default_rng(1)
for t in times:
    dict_obs[t] = {}
    for i, n in enumerate(nodes):
        OBS = os.environ.get("OBS_TYPE", "swc")
        draw = rng.normal()                       # exactly ONE draw per sensor (keeps the baselines valid)
        if OBS == "tensio":
            value, unit, err = -1.0 + 0.05 * draw, "pressure head(m)", 0.1
        elif OBS == "ETact":
            value, unit, err = 2e-8 + 1e-9 * draw, "m/s", 1e-9
        else:
            value, unit, err = 0.40 + 0.01 * draw, "m3/m3", 0.05
        dict_obs[t][f"{OBS}{i}"] = {
            "filename": None, "data_type": OBS, "units": unit,
            "data": float(value), "data_err": err,
            "mesh_nodes": np.array([n]), "assimilation_times": t, "datetime": None,
        }
_, _, stacked_data_cov = make_data_cov(simu, dict_obs, list_assimilated_obs="all")
simu.stacked_data_cov = stacked_data_cov
DEM, _ = simu.read_inputs("dem")
simu.DEM = DEM
simu.update_dem_parameters(); simu.update_veg_map(); simu.update_soil()

scenario = {"per_name": ["ic"], "per_type": [None], "per_nom": [-1.5], "per_mean": [-1.5],
            "per_sigma": [0.3], "per_bounds": [None], "sampling_type": ["normal"],
            "transf_type": [None], "listUpdateParm": ["St. var."], "listObAss": [os.environ.get("OBS_TYPE", "swc")]}
PARM2UPDATE = ["St. var."]
if os.environ.get("UPDATE_KS"):                       # case 2: states + saturated conductivity of zone 0
    scenario = {"per_name": ["ic", "Ks"], "per_type": [None, [None]], "per_nom": [-1.5, [1.88e-4]],
                "per_mean": [-1.5, [1.88e-4]], "per_sigma": [0.3, [1.0e-4]], "per_bounds": [None, None],
                "sampling_type": ["normal", "lognormal"], "transf_type": [None, "log"],
                "pert_control_name": [None, "zone"], "listUpdateParm": ["St. var.", "Ks0"], "listObAss": [os.environ.get("OBS_TYPE", "swc")]}
    PARM2UPDATE = ["St. var.", "Ks0"]
if os.environ.get("UPDATE_POROS"):                    # case 7: states + porosity of zone 0
    scenario = {"per_name": ["ic", "porosity"], "per_type": [None, [None]], "per_nom": [-1.5, [0.55]],
                "per_mean": [-1.5, [0.55]], "per_sigma": [0.3, [0.05]], "per_bounds": [None, None],
                "sampling_type": ["normal", "normal"], "transf_type": [None, None],
                "pert_control_name": [None, "zone"], "listUpdateParm": ["St. var.", "porosity0"], "listObAss": [os.environ.get("OBS_TYPE", "swc")]}
    PARM2UPDATE = ["St. var.", "porosity0"]
PC = os.environ.get("PARM_CASE")                      # cases 11-14: states + one more parameter family
OBS = os.environ.get("OBS_TYPE", "swc")
if PC == "vg":                                        # case 11: van Genuchten n of zone 0
    scenario = {"per_name": ["ic", "n_VG"], "per_type": [None, [None]], "per_nom": [-1.5, [1.46]],
                "per_mean": [-1.5, [1.46]], "per_sigma": [0.3, [0.1]], "per_bounds": [None, None],
                "sampling_type": ["normal", "normal"], "transf_type": [None, None],
                "pert_control_name": [None, "zone"], "listUpdateParm": ["St. var.", "n_VG0"], "listObAss": [OBS]}
    PARM2UPDATE = ["St. var.", "n_VG0"]
if PC == "feddes":                                    # case 12: Feddes root depth
    scenario = {"per_name": ["ic", "ZROOT"], "per_type": [None, None], "per_nom": [-1.5, 1.0],
                "per_mean": [-1.5, 1.0], "per_sigma": [0.3, 0.2], "per_bounds": [None, {"min": 0.2, "max": 2}],
                "sampling_type": ["normal", "normal"], "transf_type": [None, None],
                "listUpdateParm": ["St. var.", "ZROOT0"], "listObAss": [OBS]}
    PARM2UPDATE = ["St. var.", "ZROOT0"]
if PC == "wtpos":                                     # case 13: water table position
    scenario = {"per_name": ["WTPOSITION"], "per_type": [None], "per_nom": [2.0],
                "per_mean": [2.0], "per_sigma": [0.2], "per_bounds": [None],
                "sampling_type": ["normal"], "transf_type": [None],
                "listUpdateParm": ["St. var.", "WTPOSITION"], "listObAss": [OBS]}
    PARM2UPDATE = ["St. var.", "WTPOSITION"]
if PC == "atmbc":                                     # case 14: atmospheric forcing (needs the atmbc dataframe BEFORE perturbate)
    simu.update_atmbc(HSPATM=1, IETO=0, time=times, netValue=[-1e-8] * len(times))
    simu.run_processor(IPRT1=3, DAFLAG=0)               # writes output/grid3d, read by read_inputs("atmbc")
    simu.read_inputs("atmbc")                         # builds simu.atmbc["atmbc_df"] used by perturbate()
    scenario = {"per_name": ["ic", "atmbc"], "per_type": [None, None], "per_nom": [-1.5, 1.0],   # atmbc: log-normal MULTIPLIER of the forcing (nominal 1, spread 0.1)
                "per_mean": [-1.5, 1.0], "per_sigma": [0.3, 0.1], "per_bounds": [None, None],
                "sampling_type": ["normal", "normal"], "transf_type": [None, None],
                "time_decorrelation_len": [None, 864000.0],   # >> 86400 s: atmbc_pert_rules gives NaN when dt > Tau (upstream bug, see README)
                "listUpdateParm": ["St. var.", "atmbc0"], "listObAss": [OBS]}
    PARM2UPDATE = ["St. var.", "atmbc0"]
list_pert = perturbate.perturbate(simu, scenario, NENS)
dpp = {}
for dp in list_pert:
    savefig = os.path.join(simu.workdir, simu.project_name, simu.project_name + dp["savefig"])
    np.random.seed(1)
    dpp = perturbate.perturbate_parm(dpp, parm=dp, type_parm=dp["type_parm"], mean=dp["mean"], sd=dp["sd"],
                                     sampling_type=dp["sampling_type"], ensemble_size=dp["ensemble_size"],
                                     per_type=dp["per_type"], savefig=savefig)
for _k, _v in dpp.items():                             # fail early: a NaN perturbation would only show up as "100% members rejected"
    for _name, _arr in _v.items():
        if isinstance(_arr, np.ndarray) and _arr.dtype.kind == "f" and not np.isfinite(_arr).all():
            raise SystemExit(f"non finite perturbation {_k}/{_name}: {_arr}")
atmbc_times = sorted(times + [1800.0]) if os.environ.get("EXTRA_ATMBC") else times   # case 9: one atmbc time WITHOUT observation
simu.update_atmbc(HSPATM=1, IETO=0, time=atmbc_times, netValue=[0] * len(atmbc_times))
if not os.environ.get("SEED_IN_CONFIG"):
    np.random.seed(2)                                # baseline style: seed in the script
extra = {}
LOC = os.environ.get("LOCALISATION") or None
if LOC and not os.environ.get("USE_CONFIG"):
    extra["localisation"] = LOC                      # legacy keyword (works with the original file)
if os.environ.get("USE_CONFIG"):                     # new API: DAConfig instead of loose kwargs
    extra["config"] = cdmod.DAConfig(inflation=1.0, localisation=LOC, cleanup_vtk=os.environ.get("CLEANUP_VTK") or False, use_log_transformed_obs=bool(os.environ.get("LOG_OBS")), backup_fort777=bool(os.environ.get("BACKUP_FORT777")), seed=2 if os.environ.get("SEED_IN_CONFIG") else None, analysis=(cdmod.AnalysisConfig(sakov=False) if os.environ.get("ANALYSIS_NOSAKOV") else None), save_results=bool(os.environ.get("SAVE_RESULTS")))
simu.run_DA_sequential(VTKF=2, TRAFLAG=0, dict_obs=dict_obs, list_assimilated_obs="all",
                       list_parm2update=PARM2UPDATE, DA_type=DA_TYPE, dict_parm_pert=dpp, parallel=not os.environ.get("SERIAL"), **extra, **({"open_loop_run": False, "threshold_rejected": 80} if os.environ.get("TUTORIAL_KWARGS") else {}))   # tutorial call style (legacy kwargs)   # case 10: SERIAL=1 -> parallel=False
import glob
print("VTK files left in DA_Ensemble:", len(glob.glob(os.path.join(simu.workdir, simu.project_name, "DA_Ensemble", "**", "*.vtk"), recursive=True)))
print("RUN DONE", cdmod.__file__)
import baseline_tool
out = os.environ.get("CAPTURE_TO")
if out:
    baseline_tool.capture(simu, out)
cmp_ = os.environ.get("COMPARE_WITH")
if cmp_:
    baseline_tool.compare(simu, cmp_)
